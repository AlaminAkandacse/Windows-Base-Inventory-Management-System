﻿using MBAManagementSystem.Forms.AccountForms;
using MBAManagementSystem.Forms.CustomerForms;
using MBAManagementSystem.Forms.PurchaseForms;
using MBAManagementSystem.Forms.SaleForms;
using MBAManagementSystem.Forms.StockForms;
using MBAManagementSystem.Forms.SupplierForms;
using MBAManagementSystem.Forms.UserForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem
{
    public partial class frmMainForm : Form
    {
        frmUserTypes UserTypesForm;
        frmProducts ProductsForms;
        frmJournal JournalForm;
        frmLedger LedgerForm;
        public frmMainForm()
        {
            InitializeComponent();
        }

        private void userTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (UserTypesForm==null) 
            {
                UserTypesForm = new frmUserTypes();
                UserTypesForm.ShowDialog();
            
            }
        }

        private void addUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddUsers frm = new frmAddUsers();
            frm.ShowDialog();
        }

        private void tsbLogin_Click(object sender, EventArgs e)
        {
            frmLogin frm = new frmLogin(this);
            frm.ShowDialog();
        }

        private void frmMainForm_Load(object sender, EventArgs e)
        {
            tsbLogin.Visible = true;
            tsbLogout.Visible = false;
            msall.Enabled = false;
        }

        private void tsbLogout_ButtonClick(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdateUser frm = new frmUpdateUser();
            frm.ShowDialog();

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void categoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategories frm = new frmCategories();
            frm.ShowDialog();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ProductsForms==null) 
            {
                ProductsForms = new frmProducts();
            }
            ProductsForms.TopLevel = false;
            panelparent.Controls.Add(ProductsForms);
            ProductsForms.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            ProductsForms.Dock = DockStyle.Fill;
            ProductsForms.Show();
        }

        private void accountHeadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccountHead frm = new frmAccountHead();
            frm.ShowDialog();
        }

        private void accountControlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccountControls frm = new frmAccountControls();
            frm.ShowDialog();
        }

        private void accountSubControlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccountSubControls frm = new frmAccountSubControls();
            frm.ShowDialog();
            return;
        }

        private void financialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFinancialYear frm = new frmFinancialYear();
            frm.ShowDialog();
        }

        private void addSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSupplier frm = new frmSupplier();
            frm.ShowDialog();
        }

        private void addCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCustomer frm = new frmCustomer();
            frm.ShowDialog();
        }

        private void purchaseInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPurchaseForms frm = new frmPurchaseForms();
            frm.ShowDialog();
        }

        private void saleInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSaleForms frm = new frmSaleForms();
            frm.ShowDialog();
        }

        private void monthlyTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {         
            if (JournalForm == null)
            {
                JournalForm = new frmJournal();
            }
            JournalForm.TopLevel = false;
            panelparent.Controls.Add(JournalForm);
            JournalForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            JournalForm.Dock = DockStyle.Fill;
            JournalForm.Show();

        }

        private void purchasePaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPurchasePayment frm = new frmPurchasePayment();
            frm.ShowDialog();
        }

        private void salePaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSalePayment frm = new frmSalePayment();
            frm.ShowDialog();
        }

        private void generalInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmGeneralEntries frm = new frmGeneralEntries();
            frm.ShowDialog();
        }

        private void trialBalanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTrialBalance frm = new frmTrialBalance();
            frm.ShowDialog();
        }

        private void accountsLedgerToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (LedgerForm == null)
            {
                LedgerForm = new frmLedger();
            }
            LedgerForm.TopLevel = false;
            panelparent.Controls.Add(LedgerForm);
            LedgerForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            LedgerForm.Dock = DockStyle.Fill;
            LedgerForm.Show();
        }

        private void incomeStatementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIncomeStatement frm = new frmIncomeStatement();
            frm.ShowDialog();
        }

        private void balanceSheetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBalanceSheet frm = new frmBalanceSheet();
            frm.ShowDialog();
        }
    }
}
