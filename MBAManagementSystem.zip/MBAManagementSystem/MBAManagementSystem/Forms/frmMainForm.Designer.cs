﻿namespace MBAManagementSystem
{
    partial class frmMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainForm));
            this.msall = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suppliersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchasePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCustomersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saleInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userSettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userTypesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountsSettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountHeadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.accountControlsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountSubControlsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.financialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monthlyTransactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generalInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trialBalanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountsLedgerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incomeStatementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsall = new System.Windows.Forms.ToolStrip();
            this.tsbLogin = new System.Windows.Forms.ToolStripButton();
            this.tsbLogout = new System.Windows.Forms.ToolStripDropDownButton();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panelparent = new System.Windows.Forms.Panel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.balanceSheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.msall.SuspendLayout();
            this.tsall.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // msall
            // 
            this.msall.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.purchaseToolStripMenuItem,
            this.salesToolStripMenuItem,
            this.stockToolStripMenuItem,
            this.settingToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.transactionToolStripMenuItem});
            this.msall.Location = new System.Drawing.Point(0, 0);
            this.msall.Name = "msall";
            this.msall.Size = new System.Drawing.Size(800, 24);
            this.msall.TabIndex = 0;
            this.msall.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // purchaseToolStripMenuItem
            // 
            this.purchaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.suppliersToolStripMenuItem,
            this.purchaseInvoiceToolStripMenuItem,
            this.purchasePaymentToolStripMenuItem});
            this.purchaseToolStripMenuItem.Name = "purchaseToolStripMenuItem";
            this.purchaseToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.purchaseToolStripMenuItem.Text = "Purchase";
            // 
            // suppliersToolStripMenuItem
            // 
            this.suppliersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addSupplierToolStripMenuItem});
            this.suppliersToolStripMenuItem.Name = "suppliersToolStripMenuItem";
            this.suppliersToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.suppliersToolStripMenuItem.Text = "Suppliers";
            // 
            // addSupplierToolStripMenuItem
            // 
            this.addSupplierToolStripMenuItem.Name = "addSupplierToolStripMenuItem";
            this.addSupplierToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.addSupplierToolStripMenuItem.Text = "Add Supplier";
            this.addSupplierToolStripMenuItem.Click += new System.EventHandler(this.addSupplierToolStripMenuItem_Click);
            // 
            // purchaseInvoiceToolStripMenuItem
            // 
            this.purchaseInvoiceToolStripMenuItem.Name = "purchaseInvoiceToolStripMenuItem";
            this.purchaseInvoiceToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.purchaseInvoiceToolStripMenuItem.Text = "Purchase Invoice";
            this.purchaseInvoiceToolStripMenuItem.Click += new System.EventHandler(this.purchaseInvoiceToolStripMenuItem_Click);
            // 
            // purchasePaymentToolStripMenuItem
            // 
            this.purchasePaymentToolStripMenuItem.Name = "purchasePaymentToolStripMenuItem";
            this.purchasePaymentToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.purchasePaymentToolStripMenuItem.Text = "Purchase Payment";
            this.purchasePaymentToolStripMenuItem.Click += new System.EventHandler(this.purchasePaymentToolStripMenuItem_Click);
            // 
            // salesToolStripMenuItem
            // 
            this.salesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customersToolStripMenuItem,
            this.saleInvoiceToolStripMenuItem,
            this.salePaymentToolStripMenuItem});
            this.salesToolStripMenuItem.Name = "salesToolStripMenuItem";
            this.salesToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.salesToolStripMenuItem.Text = "Sales";
            // 
            // customersToolStripMenuItem
            // 
            this.customersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCustomersToolStripMenuItem});
            this.customersToolStripMenuItem.Name = "customersToolStripMenuItem";
            this.customersToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.customersToolStripMenuItem.Text = "Customers";
            // 
            // addCustomersToolStripMenuItem
            // 
            this.addCustomersToolStripMenuItem.Name = "addCustomersToolStripMenuItem";
            this.addCustomersToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.addCustomersToolStripMenuItem.Text = "Add Customers";
            this.addCustomersToolStripMenuItem.Click += new System.EventHandler(this.addCustomersToolStripMenuItem_Click);
            // 
            // saleInvoiceToolStripMenuItem
            // 
            this.saleInvoiceToolStripMenuItem.Name = "saleInvoiceToolStripMenuItem";
            this.saleInvoiceToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.saleInvoiceToolStripMenuItem.Text = "Sale Invoice";
            this.saleInvoiceToolStripMenuItem.Click += new System.EventHandler(this.saleInvoiceToolStripMenuItem_Click);
            // 
            // salePaymentToolStripMenuItem
            // 
            this.salePaymentToolStripMenuItem.Name = "salePaymentToolStripMenuItem";
            this.salePaymentToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.salePaymentToolStripMenuItem.Text = "Sale Payment";
            this.salePaymentToolStripMenuItem.Click += new System.EventHandler(this.salePaymentToolStripMenuItem_Click);
            // 
            // stockToolStripMenuItem
            // 
            this.stockToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.categoriesToolStripMenuItem,
            this.productsToolStripMenuItem});
            this.stockToolStripMenuItem.Name = "stockToolStripMenuItem";
            this.stockToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.stockToolStripMenuItem.Text = "Stock";
            // 
            // categoriesToolStripMenuItem
            // 
            this.categoriesToolStripMenuItem.Name = "categoriesToolStripMenuItem";
            this.categoriesToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.categoriesToolStripMenuItem.Text = "Categories";
            this.categoriesToolStripMenuItem.Click += new System.EventHandler(this.categoriesToolStripMenuItem_Click);
            // 
            // productsToolStripMenuItem
            // 
            this.productsToolStripMenuItem.Name = "productsToolStripMenuItem";
            this.productsToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.productsToolStripMenuItem.Text = "Products";
            this.productsToolStripMenuItem.Click += new System.EventHandler(this.productsToolStripMenuItem_Click);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userSettingToolStripMenuItem,
            this.accountsSettingToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.settingToolStripMenuItem.Text = "Setting";
            // 
            // userSettingToolStripMenuItem
            // 
            this.userSettingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userTypesToolStripMenuItem,
            this.addUsersToolStripMenuItem});
            this.userSettingToolStripMenuItem.Name = "userSettingToolStripMenuItem";
            this.userSettingToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.userSettingToolStripMenuItem.Text = "User Setting";
            // 
            // userTypesToolStripMenuItem
            // 
            this.userTypesToolStripMenuItem.Name = "userTypesToolStripMenuItem";
            this.userTypesToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.userTypesToolStripMenuItem.Text = "User Types";
            this.userTypesToolStripMenuItem.Click += new System.EventHandler(this.userTypesToolStripMenuItem_Click);
            // 
            // addUsersToolStripMenuItem
            // 
            this.addUsersToolStripMenuItem.Name = "addUsersToolStripMenuItem";
            this.addUsersToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.addUsersToolStripMenuItem.Text = "Add users";
            this.addUsersToolStripMenuItem.Click += new System.EventHandler(this.addUsersToolStripMenuItem_Click);
            // 
            // accountsSettingToolStripMenuItem
            // 
            this.accountsSettingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountHeadToolStripMenuItem,
            this.toolStripSeparator1,
            this.accountControlsToolStripMenuItem,
            this.accountSubControlsToolStripMenuItem,
            this.toolStripSeparator2,
            this.financialToolStripMenuItem});
            this.accountsSettingToolStripMenuItem.Name = "accountsSettingToolStripMenuItem";
            this.accountsSettingToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.accountsSettingToolStripMenuItem.Text = "Accounts Setting";
            // 
            // accountHeadToolStripMenuItem
            // 
            this.accountHeadToolStripMenuItem.Name = "accountHeadToolStripMenuItem";
            this.accountHeadToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.accountHeadToolStripMenuItem.Text = "Account Head";
            this.accountHeadToolStripMenuItem.Click += new System.EventHandler(this.accountHeadToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(187, 6);
            // 
            // accountControlsToolStripMenuItem
            // 
            this.accountControlsToolStripMenuItem.Name = "accountControlsToolStripMenuItem";
            this.accountControlsToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.accountControlsToolStripMenuItem.Text = "Account Controls";
            this.accountControlsToolStripMenuItem.Click += new System.EventHandler(this.accountControlsToolStripMenuItem_Click);
            // 
            // accountSubControlsToolStripMenuItem
            // 
            this.accountSubControlsToolStripMenuItem.Name = "accountSubControlsToolStripMenuItem";
            this.accountSubControlsToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.accountSubControlsToolStripMenuItem.Text = "Account Sub Controls";
            this.accountSubControlsToolStripMenuItem.Click += new System.EventHandler(this.accountSubControlsToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(187, 6);
            // 
            // financialToolStripMenuItem
            // 
            this.financialToolStripMenuItem.Name = "financialToolStripMenuItem";
            this.financialToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.financialToolStripMenuItem.Text = "Financial Year";
            this.financialToolStripMenuItem.Click += new System.EventHandler(this.financialToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.monthlyTransactionToolStripMenuItem,
            this.toolStripSeparator3,
            this.generalInvoiceToolStripMenuItem,
            this.toolStripSeparator4,
            this.trialBalanceToolStripMenuItem,
            this.toolStripSeparator5,
            this.accountsLedgerToolStripMenuItem,
            this.toolStripSeparator6,
            this.incomeStatementToolStripMenuItem,
            this.balanceSheetToolStripMenuItem,
            this.toolStripSeparator7});
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.transactionToolStripMenuItem.Text = "Transaction";
            // 
            // monthlyTransactionToolStripMenuItem
            // 
            this.monthlyTransactionToolStripMenuItem.Name = "monthlyTransactionToolStripMenuItem";
            this.monthlyTransactionToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.monthlyTransactionToolStripMenuItem.Text = "Monthly Transactions";
            this.monthlyTransactionToolStripMenuItem.Click += new System.EventHandler(this.monthlyTransactionToolStripMenuItem_Click);
            // 
            // generalInvoiceToolStripMenuItem
            // 
            this.generalInvoiceToolStripMenuItem.Name = "generalInvoiceToolStripMenuItem";
            this.generalInvoiceToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.generalInvoiceToolStripMenuItem.Text = "General Invoice";
            this.generalInvoiceToolStripMenuItem.Click += new System.EventHandler(this.generalInvoiceToolStripMenuItem_Click);
            // 
            // trialBalanceToolStripMenuItem
            // 
            this.trialBalanceToolStripMenuItem.Name = "trialBalanceToolStripMenuItem";
            this.trialBalanceToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.trialBalanceToolStripMenuItem.Text = "Trial Balance";
            this.trialBalanceToolStripMenuItem.Click += new System.EventHandler(this.trialBalanceToolStripMenuItem_Click);
            // 
            // accountsLedgerToolStripMenuItem
            // 
            this.accountsLedgerToolStripMenuItem.Name = "accountsLedgerToolStripMenuItem";
            this.accountsLedgerToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.accountsLedgerToolStripMenuItem.Text = "Accounts Ledger";
            this.accountsLedgerToolStripMenuItem.Click += new System.EventHandler(this.accountsLedgerToolStripMenuItem_Click);
            // 
            // incomeStatementToolStripMenuItem
            // 
            this.incomeStatementToolStripMenuItem.Name = "incomeStatementToolStripMenuItem";
            this.incomeStatementToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.incomeStatementToolStripMenuItem.Text = "Income Statement";
            this.incomeStatementToolStripMenuItem.Click += new System.EventHandler(this.incomeStatementToolStripMenuItem_Click);
            // 
            // tsall
            // 
            this.tsall.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.tsall.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLogin,
            this.tsbLogout});
            this.tsall.Location = new System.Drawing.Point(0, 24);
            this.tsall.Name = "tsall";
            this.tsall.Size = new System.Drawing.Size(800, 46);
            this.tsall.TabIndex = 1;
            this.tsall.Text = "toolStrip1";
            // 
            // tsbLogin
            // 
            this.tsbLogin.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsbLogin.Image = ((System.Drawing.Image)(resources.GetObject("tsbLogin.Image")));
            this.tsbLogin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLogin.Name = "tsbLogin";
            this.tsbLogin.Size = new System.Drawing.Size(41, 43);
            this.tsbLogin.Text = "Login";
            this.tsbLogin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbLogin.Click += new System.EventHandler(this.tsbLogin_Click);
            // 
            // tsbLogout
            // 
            this.tsbLogout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsbLogout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changePasswordToolStripMenuItem,
            this.logoutToolStripMenuItem1});
            this.tsbLogout.Image = ((System.Drawing.Image)(resources.GetObject("tsbLogout.Image")));
            this.tsbLogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLogout.Name = "tsbLogout";
            this.tsbLogout.Size = new System.Drawing.Size(58, 43);
            this.tsbLogout.Text = "Logout";
            this.tsbLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbLogout.Visible = false;
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.changePasswordToolStripMenuItem.Text = "Update Profile";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem1
            // 
            this.logoutToolStripMenuItem1.Name = "logoutToolStripMenuItem1";
            this.logoutToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.logoutToolStripMenuItem1.Text = "Logout";
            this.logoutToolStripMenuItem1.Click += new System.EventHandler(this.logoutToolStripMenuItem1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(69, 17);
            this.toolStripStatusLabel1.Text = "    Ready......";
            // 
            // panelparent
            // 
            this.panelparent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelparent.Location = new System.Drawing.Point(0, 70);
            this.panelparent.Name = "panelparent";
            this.panelparent.Size = new System.Drawing.Size(800, 358);
            this.panelparent.TabIndex = 3;
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(184, 6);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(184, 6);
            // 
            // balanceSheetToolStripMenuItem
            // 
            this.balanceSheetToolStripMenuItem.Name = "balanceSheetToolStripMenuItem";
            this.balanceSheetToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.balanceSheetToolStripMenuItem.Text = "Balance Sheet";
            this.balanceSheetToolStripMenuItem.Click += new System.EventHandler(this.balanceSheetToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(184, 6);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(184, 6);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(184, 6);
            // 
            // frmMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelparent);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tsall);
            this.Controls.Add(this.msall);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.msall;
            this.Name = "frmMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Master Business Associats Management System";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMainForm_Load);
            this.msall.ResumeLayout(false);
            this.msall.PerformLayout();
            this.tsall.ResumeLayout(false);
            this.tsall.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStrip tsall;
        private System.Windows.Forms.ToolStripMenuItem userSettingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userTypesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUsersToolStripMenuItem;
        public System.Windows.Forms.ToolStripButton tsbLogin;
        public System.Windows.Forms.MenuStrip msall;
        public System.Windows.Forms.ToolStripDropDownButton tsbLogout;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem categoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productsToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Panel panelparent;
        private System.Windows.Forms.ToolStripMenuItem accountsSettingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountHeadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountControlsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountSubControlsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem financialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suppliersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCustomersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saleInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monthlyTransactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchasePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generalInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trialBalanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountsLedgerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incomeStatementToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem balanceSheetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
    }
}