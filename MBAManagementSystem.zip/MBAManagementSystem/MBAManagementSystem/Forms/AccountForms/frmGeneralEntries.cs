﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmGeneralEntries : Form
    {
        public frmGeneralEntries()
        {
            InitializeComponent();
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void frmGeneralEntries_Load(object sender, EventArgs e)
        {
            ComboHelper.FillAccountHeadControls(cmbAllAccountDebit);
            ComboHelper.FillAccountHeadControls(cmbAllAccountCredit);
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbAllAccountDebit.SelectedIndex==0) 
            {
                ep.SetError(cmbAllAccountDebit,"Please Select Debit Account");
                cmbAllAccountDebit.Focus();
                return;
            }
            if (cmbAllAccountCredit.SelectedIndex == 0)
            {
                ep.SetError(cmbAllAccountCredit, "Please Select Credit Account");
                cmbAllAccountCredit.Focus();
                return;
            }

            float amount = 0;
            float.TryParse(txtAmount.Text.Trim(), out amount);
            if (amount== 0)
            {
                ep.SetError(txtAmount, "Please Enter General Transaction Amount!");
                txtAmount.Focus();
                return;
            }

            if (txtDescription.Text.Trim().Length == 0)
            {
                ep.SetError(txtDescription, "Please Enter Transaction Reason!");
                txtDescription.Focus();
                return;
            }


            string AccountHeadID = string.Empty;
            string AccountControlID = string.Empty;
            string AccountSubControlID = string.Empty;
            Accounts.GetAccountDetails(cmbAllAccountCredit.Text.Trim(), out AccountHeadID, out AccountControlID, out AccountSubControlID);

            string FinancialYearID = (DatabaseAccess.Retrive("select top 1 FinancialYearID from FinancialYearTable where IsActive=1") != null ? Convert.ToString(DatabaseAccess.Retrive("select top 1 financialYearID from FinancialYearTable where IsActive=1").Rows[0][0]) : string.Empty);
            string payinvoiceno = "GEN" + DateTime.Now.ToString("ddMMyyyyHHmmssmm");
           
            string transactiontitle = txtDescription.Text.Trim();
            string creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
            FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, payinvoiceno, CurrentUser.UserID, amount, "0", DateTime.Now, transactiontitle);


            AccountHeadID = string.Empty;
            AccountControlID = string.Empty;
            AccountSubControlID = string.Empty;
            Accounts.GetAccountDetails(cmbAllAccountDebit.Text.Trim(), out AccountHeadID, out AccountControlID, out AccountSubControlID);

            transactiontitle = "General Transaction Succesed";
            string debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
              FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, payinvoiceno, CurrentUser.UserID, "0", amount, DateTime.Now, transactiontitle);

            DatabaseAccess.Insert(creditquery);
            DatabaseAccess.Insert(debittquery);

            MessageBox.Show("General Transaction Successfull");
            this.Close();

        }
    }
}
