﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmFinancialYear : Form
    {
        public frmFinancialYear()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select FinancialYearID, FinancialYear, StartDate, EndDate, IsActive from FinancialYearTable";
            }
            else
            {
                query = "select FinancialYearID, FinancialYear, StartDate, EndDate, IsActive from FinancialYearTable where (FinancialYear) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvFinancialYearList.DataSource = dt;
                    dgvFinancialYearList.Columns[0].Width = 100;
                    dgvFinancialYearList.Columns[1].Width = 100;
                    dgvFinancialYearList.Columns[2].Width = 100;
                    dgvFinancialYearList.Columns[3].Width = 100;
                    dgvFinancialYearList.Columns[4].Width = 100;
                }
                else
                {
                    dgvFinancialYearList.DataSource = null;
                }
            }
            else
            {
                dgvFinancialYearList.DataSource = null;
            }
        }

        private void EnableComponent()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvFinancialYearList.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvFinancialYearList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            ResetForm();
        }

        private void ResetForm()
        {
            dtpStartDate.Value = DateTime.Now;
            txtFinancialYearTitle.Clear();
        }
        private void frmFinancialYear_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvFinancialYearList != null)
            {
                if (dgvFinancialYearList.Rows.Count > 0)
                {
                    if (dgvFinancialYearList.SelectedRows.Count == 1)
                    {
                        txtFinancialYearTitle.Text = Convert.ToString(dgvFinancialYearList.CurrentRow.Cells[1].Value);
                        dtpStartDate.Value = Convert.ToDateTime(dgvFinancialYearList.CurrentRow.Cells[2].Value);
                        chkIsActive.Checked = Convert.ToBoolean(dgvFinancialYearList.CurrentRow.Cells[4].Value);
                        EnableComponent();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtFinancialYearTitle.Text.Trim().Length==0) 
            {
                ep.SetError(txtFinancialYearTitle,"Please Financial Year Title");
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from FinancialYearTable where FinancialYear='"+txtFinancialYearTitle.Text.Trim()+"'");
            if (dt !=null) 
            {
                if (dt.Rows.Count>0) 
                {
                    ep.SetError(txtFinancialYearTitle,"Already Exist");
                    return;
                }
            }

            string insertquery = string.Format("insert into FinancialYearTable(FinancialYear, StartDate, EndDate, IsActive) values('{0}','{1}',DateAdd(day,-1,(DateAdd(YY,1,'{2}'))),'{3}')",txtFinancialYearTitle.Text.Trim(),dtpStartDate.Value.ToString("dd/MM/yyyy"), dtpStartDate.Value.ToString("dd/MM/yyyy"),chkIsActive.Checked);
            bool result = DatabaseAccess.Insert(insertquery);
            if (result)

            {
                MessageBox.Show("Save Successfully");
                ResetForm();
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Unexpected Error is occur Please contact to concer person");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtFinancialYearTitle.Text.Trim().Length == 0)
            {
                ep.SetError(txtFinancialYearTitle, "Please Financial Year Title");
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from FinancialYearTable where FinancialYear='" + txtFinancialYearTitle.Text.Trim() + "' and FinancialYearID !='"+dgvFinancialYearList.CurrentRow.Cells[0].Value+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtFinancialYearTitle, "Already Exist");
                    txtFinancialYearTitle.Focus();
                    return;
                }
            }

            string updatequery = string.Format("update FinancialYearTable set FinancialYear='{0}', StartDate='{1}', EndDate=DateAdd(day,-1,(DateAdd(YY,1,'{2}'))), IsActive='{3}' where FinancialYearID='{4}'", txtFinancialYearTitle.Text.Trim(), dtpStartDate.Value.ToString("dd/MM/yyyy"), dtpStartDate.Value.ToString("dd/MM/yyyy"), chkIsActive.Checked,dgvFinancialYearList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(updatequery);
            if (result)

            {
                MessageBox.Show("Update Successfully");
                DesibleControls();
            }
            else
            {
                MessageBox.Show("Unexpected Error is occur Please contact to concer person");
            }
        }
    }
}
