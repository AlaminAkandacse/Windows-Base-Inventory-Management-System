﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmLedger : Form
    {
        public frmLedger()
        {
            InitializeComponent();

            dgvLedger.Columns[0].Width = 150;
            dgvLedger.Columns[1].Width = 150;
            dgvLedger.Columns[2].Width = 350;
            dgvLedger.Columns[3].Width = 102;
            dgvLedger.Columns[4].Width = 102;
            SourceCode.GridViewDesign.JournalGridviewDesign(dgvLedger);

        }

        private void GetLedgers(string financialyearid) 
        {
            dgvLedger.Rows.Clear();
            string query = string.Empty;
            if (string.IsNullOrEmpty(financialyearid))
            {
                query = "SELECT [TransactionID],[FinancialYearID],[FinancialYear],[AccountHeadID],[AccountHeadName],[AccountControlID],[AccountControlName],[AccountSubControlID],[InvoiceNo],[TransactionDate],[TransactionTitle],[Debit],[Credit],[UserID],[UserName] FROM v_Journal order by AccountControlID";
            }
            else if (financialyearid=="0")
            {
                query = "SELECT [TransactionID],[FinancialYearID],[FinancialYear],[AccountHeadID],[AccountHeadName],[AccountControlID],[AccountControlName],[AccountSubControlID],[InvoiceNo],[TransactionDate],[TransactionTitle],[Debit],[Credit],[UserID],[UserName] FROM v_Journal order by AccountControlID";
            }
            else 
            {
                query = "SELECT [TransactionID],[FinancialYearID],[FinancialYear],[AccountHeadID],[AccountHeadName],[AccountControlID],[AccountControlName],[AccountSubControlID],[InvoiceNo],[TransactionDate],[TransactionTitle],[Debit],[Credit],[UserID],[UserName] FROM v_Journal where FinancialYearID='" + financialyearid.Trim()+ "' order by AccountControlID";

            }
            DataTable journaldb = DatabaseAccess.Retrive(query);
            if (journaldb == null) 
            {
                dgvLedger.Rows.Clear();
                return;
            }

            if (journaldb.Rows.Count == 0)
            {
                dgvLedger.Rows.Clear();
                return;
            }

            float debit = 0;
            float credit = 0;
            int totalrecords = 0;
            string accountname = string.Empty;
            foreach (DataRow row in journaldb.Rows) 
            {
                float ldebit = 0;
                float lcredit = 0;
                if (accountname == Convert.ToString(row[6]).Trim())
                {
                
                    DataGridViewRow createrow = new DataGridViewRow();
                    createrow.CreateCells(dgvLedger);
                    //createrow.Cells[0].Value = Convert.ToString(row[6]);//Account Control Name
                    //dgvLedger.Rows.Add(createrow);
                    createrow.Cells[1].Value = Convert.ToString(row[9]);//TransactionDate
                    createrow.Cells[2].Value = Convert.ToString(row[10]);//TransactionTitle
                    float.TryParse(Convert.ToString(row[11]), out ldebit);
                    debit = debit + ldebit;
                    createrow.Cells[3].Value = Convert.ToString(row[11]);//Debit
                    float.TryParse(Convert.ToString(row[12]), out lcredit);
                    credit = credit + lcredit;
                    createrow.Cells[4].Value = Convert.ToString(row[12]);//Credit
                    dgvLedger.Rows.Add(createrow);
                   
                }
                else 
                {
                    if (!string.IsNullOrEmpty(accountname))
                    {
                        DataGridViewRow totalrow = new DataGridViewRow();
                        totalrow.CreateCells(dgvLedger);
                        totalrow.Cells[1].Value = "Total";//Account Control Name
                        if (credit >= debit)
                        {
                            totalrow.Cells[4].Value = Convert.ToString(debit - credit).Replace('-', ' ');
                        }
                        else if (credit <= debit)
                        {

                            totalrow.Cells[3].Value = Convert.ToString(debit - credit).Replace('-',' ');
                        }
                        totalrow.Cells[1].Value = "Total Balance";//Account Control Name
                        dgvLedger.Rows.Add(totalrow);

                    }


                    DataGridViewRow headerrow = new DataGridViewRow();
                    headerrow.CreateCells(dgvLedger);
                    headerrow.Cells[0].Value = Convert.ToString(row[6]);//Account Control Name
                    headerrow.Cells[1].Value = "Date";
                    headerrow.Cells[2].Value = "Description";
                    headerrow.Cells[3].Value = "Debit";
                    headerrow.Cells[4].Value = "Credit";
             
                    headerrow.DefaultCellStyle = new DataGridViewCellStyle() { BackColor = Color.Gray, ForeColor=Color.White };
                    dgvLedger.Rows.Add(headerrow);
                    debit = 0;
                    credit = 0;

                    DataGridViewRow createrow = new DataGridViewRow();
                    createrow.CreateCells(dgvLedger);
                    createrow.Cells[1].Value = Convert.ToString(row[9]);//TransactionDate
                    createrow.Cells[2].Value = Convert.ToString(row[10]);//TransactionTitle
                    float.TryParse(Convert.ToString(row[11]), out ldebit);
                    debit = debit + ldebit;
                    createrow.Cells[3].Value = Convert.ToString(row[11]);//Debit
                    float.TryParse(Convert.ToString(row[12]), out lcredit);
                    credit = credit + lcredit;
                    createrow.Cells[4].Value = Convert.ToString(row[12]);//Credit 
                    dgvLedger.Rows.Add(createrow);
                    accountname = Convert.ToString(row[6]).Trim();

                }
                totalrecords = totalrecords + 1;
                if (totalrecords == journaldb.Rows.Count)
                {
                    DataGridViewRow totalrow = new DataGridViewRow();
                    totalrow.CreateCells(dgvLedger);
                    totalrow.Cells[1].Value = "Total";//Account Control Name
                    if (credit >= debit)
                    {
                        totalrow.Cells[4].Value = Convert.ToString(debit - credit).Replace('-', ' ');
                    }
                    else if (credit <= debit)
                    {

                        totalrow.Cells[3].Value = Convert.ToString(debit - credit).Replace('-', ' ');
                    }
                    totalrow.Cells[1].Value = "Total Balance";//Account Control Name
                    dgvLedger.Rows.Add(totalrow);
                    debit = 0;
                    credit = 0;
                }
         
            }
           

        }


        private void frmLedger_Load(object sender, EventArgs e)
        {
            ComboHelper.FillFinancialYear(cmbFinancialYear);
            GetLedgers("");
        }

        private void cmbFinancialYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetLedgers(Convert.ToString(cmbFinancialYear.SelectedValue));
        }
    }
}
