﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmJournal : Form
    {
        public frmJournal()
        {
            InitializeComponent();
            SetColumnsWidth();
            GridViewDesign.JournalGridviewDesign(dgvJournal);
        }
        private void GetJournalEntries() 
        {
            string query = string.Format("Select TransactionID,FinancialYearID,FinancialYear,AccountHeadID,AccountHeadName," +
                "TransactionDate [Date],TransactionTitle [Transaction],InvoiceNo [Invoice No],AccountControlID,AccountControlName [Account]," +
                "AccountSubControlID, CASE Debit WHEN 0 THEN NULL ELSE Debit END as Debit, CASE Credit WHEN 0 THEN NULL ELSE Credit END as Credit," +
                "UserName [User] from v_Journal order by TransactionDate desc");
            DataTable dt = DatabaseAccess.Retrive(query);

            if (dt != null)
            {
                //dgvJournal.DataSource = dt;
                string invoiceno = string.Empty;
                foreach (DataRow item in dt.Rows)  
                {
                    DataGridViewRow addtransaction = new DataGridViewRow();
                    addtransaction.CreateCells(dgvJournal);
                    if (invoiceno != Convert.ToString(item[7]))
                    {
                        invoiceno = Convert.ToString(item[7]);
                        addtransaction.Cells[7].Value = Convert.ToString(Convert.ToString(item[7]));
                        addtransaction.Cells[7].Style = new DataGridViewCellStyle() { BackColor = Color.Gray };
                    }
                    else 
                    {
                        addtransaction.Cells[7].Value = Convert.ToString(Convert.ToString(item[7]));
                        addtransaction.Cells[7].Style = new DataGridViewCellStyle() { ForeColor = Color.White };
                        addtransaction.Cells[5].Style = new DataGridViewCellStyle() { ForeColor = Color.White };
                        addtransaction.Cells[13].Style = new DataGridViewCellStyle() { ForeColor = Color.White };
                    }

                    addtransaction.Cells[0].Value  =  Convert.ToString(item[0]);
                    addtransaction.Cells[1].Value  =  Convert.ToString(item[1]);
                    addtransaction.Cells[2].Value  =  Convert.ToString(item[2]);
                    addtransaction.Cells[3].Value  =  Convert.ToString(item[3]);
                    addtransaction.Cells[4].Value  =  Convert.ToString(item[4]);
                    addtransaction.Cells[5].Value  =  Convert.ToString(item[5]);
                    addtransaction.Cells[6].Value  =  Convert.ToString(item[6]);
                    addtransaction.Cells[7].Value  =  Convert.ToString(item[7]);
                    addtransaction.Cells[8].Value  =  Convert.ToString(item[8]);
                    addtransaction.Cells[9].Value  =  Convert.ToString(item[9]);
                    addtransaction.Cells[10].Value =  Convert.ToString(item[10]);
                    addtransaction.Cells[11].Value =  Convert.ToString(item[11]);
                    addtransaction.Cells[12].Value =  Convert.ToString(item[12]);
                    addtransaction.Cells[13].Value =  Convert.ToString(item[13]);
                    dgvJournal.Rows.Add(addtransaction);

                }
           

            }
            else 
            {
                //dgvJournal.DataSource = null;
            }
        }

        private void SetColumnsWidth() 
        {

            dgvJournal.Columns[0].Visible = false;//Transaction ID
            dgvJournal.Columns[1].Visible = false;//FinancialYear ID
            dgvJournal.Columns[2].Visible = false;//FinancialYear
            dgvJournal.Columns[3].Visible = false;//AccountHeadID
            dgvJournal.Columns[4].Visible = false;//AccountName
            dgvJournal.Columns[5].Width = 150;//TransactionDate
            dgvJournal.Columns[6].Width = 400;//TransactionTitle
            dgvJournal.Columns[7].Width = 150;//InvoiceNo
            dgvJournal.Columns[8].Visible = false;//AccountControlID
            dgvJournal.Columns[9].Width = 150;//AccountControlName
            dgvJournal.Columns[10].Visible = false;//AccountSubControlID
            dgvJournal.Columns[11].Width = 120;//Debit
            dgvJournal.Columns[12].Width = 120;//Credit
            dgvJournal.Columns[13].Width = 120;//UserName
            dgvJournal.Columns[11].DefaultCellStyle = new DataGridViewCellStyle()
            {
                //BackColor = Color.White,
                //ForeColor = Color.White,
                //SelectionBackColor = Color.White,
                //SelectionForeColor = Color.White,
                Alignment = DataGridViewContentAlignment.MiddleRight,
                //Padding = new Padding {All = 0 },
                //WrapMode=DataGridViewTriState.NotSet

            };
            dgvJournal.Columns[12].DefaultCellStyle = new DataGridViewCellStyle()
            {
                //BackColor = Color.White,
                //ForeColor = Color.White,
                //SelectionBackColor = Color.White,
                //SelectionForeColor = Color.White,
                Alignment = DataGridViewContentAlignment.MiddleRight,
                //Padding = new Padding { All = 0 },
                //WrapMode = DataGridViewTriState.NotSet

            };

        }
        private void frmJournal_Load(object sender, EventArgs e)
        {
            GetJournalEntries();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (dgvJournal !=null) 
            {
                if (dgvJournal.Rows.Count>0) 
                {
                    if (dgvJournal.SelectedRows.Count==1) 
                    {
                        if (dgvJournal.SelectedRows.Count==1) 
                        {
                            if (Convert.ToString(dgvJournal.CurrentRow.Cells[7].Value).Trim().Contains("PUR"))
                            {
                                paymentToolStripMenuItem.Enabled = true;
                                paidToolStripMenuItem.Enabled = false;
                            }
                            else if(Convert.ToString(dgvJournal.CurrentRow.Cells[7].Value).Trim().Contains("INV"))
                            {
                                paymentToolStripMenuItem.Enabled = false;
                                paidToolStripMenuItem.Enabled = true;
                            }
                        }
                    }
                }
            }
        }
    }
}
