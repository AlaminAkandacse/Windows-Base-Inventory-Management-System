﻿namespace MBAManagementSystem.Forms.AccountForms
{
    partial class frmAccountSubControls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAddAccountHead = new System.Windows.Forms.Button();
            this.cmbSelectAccountHead = new System.Windows.Forms.ComboBox();
            this.ep = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnRefreshHead = new System.Windows.Forms.Button();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvAccountsSubControlsList = new System.Windows.Forms.DataGridView();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.txtAccountSubControl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRefeshControl = new System.Windows.Forms.Button();
            this.cmbSelectControl = new System.Windows.Forms.ComboBox();
            this.btnAddAccountControl = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ep)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountsSubControlsList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddAccountHead
            // 
            this.btnAddAccountHead.BackgroundImage = global::MBAManagementSystem.Properties.Resources.AddUser;
            this.btnAddAccountHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddAccountHead.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddAccountHead.Location = new System.Drawing.Point(364, 14);
            this.btnAddAccountHead.Name = "btnAddAccountHead";
            this.btnAddAccountHead.Size = new System.Drawing.Size(22, 19);
            this.btnAddAccountHead.TabIndex = 41;
            this.btnAddAccountHead.UseVisualStyleBackColor = true;
            this.btnAddAccountHead.Click += new System.EventHandler(this.btnAddAccountHead_Click);
            // 
            // cmbSelectAccountHead
            // 
            this.cmbSelectAccountHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectAccountHead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSelectAccountHead.FormattingEnabled = true;
            this.cmbSelectAccountHead.Location = new System.Drawing.Point(134, 12);
            this.cmbSelectAccountHead.Name = "cmbSelectAccountHead";
            this.cmbSelectAccountHead.Size = new System.Drawing.Size(196, 21);
            this.cmbSelectAccountHead.TabIndex = 39;
            this.cmbSelectAccountHead.SelectedIndexChanged += new System.EventHandler(this.cmbSelectAccountHead_SelectedIndexChanged);
            // 
            // ep
            // 
            this.ep.ContainerControl = this;
            // 
            // btnRefreshHead
            // 
            this.btnRefreshHead.BackgroundImage = global::MBAManagementSystem.Properties.Resources.refresh;
            this.btnRefreshHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefreshHead.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRefreshHead.Location = new System.Drawing.Point(336, 14);
            this.btnRefreshHead.Name = "btnRefreshHead";
            this.btnRefreshHead.Size = new System.Drawing.Size(22, 19);
            this.btnRefreshHead.TabIndex = 40;
            this.btnRefreshHead.UseVisualStyleBackColor = true;
            this.btnRefreshHead.Click += new System.EventHandler(this.btnRefreshHead_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(95, 26);
            // 
            // btnCancel
            // 
            this.btnCancel.Enabled = false;
            this.btnCancel.Location = new System.Drawing.Point(377, 111);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 35;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Location = new System.Drawing.Point(296, 111);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 36;
            this.btnEdit.Text = "Update";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(215, 111);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 37;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(134, 111);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 38;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(18, 143);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(468, 10);
            this.panel1.TabIndex = 34;
            // 
            // dgvAccountsSubControlsList
            // 
            this.dgvAccountsSubControlsList.AllowUserToAddRows = false;
            this.dgvAccountsSubControlsList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvAccountsSubControlsList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAccountsSubControlsList.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvAccountsSubControlsList.Location = new System.Drawing.Point(15, 187);
            this.dgvAccountsSubControlsList.MultiSelect = false;
            this.dgvAccountsSubControlsList.Name = "dgvAccountsSubControlsList";
            this.dgvAccountsSubControlsList.ReadOnly = true;
            this.dgvAccountsSubControlsList.RowHeadersVisible = false;
            this.dgvAccountsSubControlsList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAccountsSubControlsList.Size = new System.Drawing.Size(471, 203);
            this.dgvAccountsSubControlsList.TabIndex = 33;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(102, 159);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(384, 20);
            this.txtSearch.TabIndex = 31;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // txtAccountSubControl
            // 
            this.txtAccountSubControl.Location = new System.Drawing.Point(134, 85);
            this.txtAccountSubControl.Name = "txtAccountSubControl";
            this.txtAccountSubControl.Size = new System.Drawing.Size(318, 20);
            this.txtAccountSubControl.TabIndex = 32;
            this.txtAccountSubControl.TextChanged += new System.EventHandler(this.txtAccountSubControl_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Search :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Select Account Head :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Enter Sub Control :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Select Account Control :";
            // 
            // btnRefeshControl
            // 
            this.btnRefeshControl.BackgroundImage = global::MBAManagementSystem.Properties.Resources.refresh;
            this.btnRefeshControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefeshControl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRefeshControl.Location = new System.Drawing.Point(336, 51);
            this.btnRefeshControl.Name = "btnRefeshControl";
            this.btnRefeshControl.Size = new System.Drawing.Size(22, 19);
            this.btnRefeshControl.TabIndex = 40;
            this.btnRefeshControl.UseVisualStyleBackColor = true;
            this.btnRefeshControl.Click += new System.EventHandler(this.btnRefeshControl_Click);
            // 
            // cmbSelectControl
            // 
            this.cmbSelectControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectControl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSelectControl.FormattingEnabled = true;
            this.cmbSelectControl.Location = new System.Drawing.Point(134, 49);
            this.cmbSelectControl.Name = "cmbSelectControl";
            this.cmbSelectControl.Size = new System.Drawing.Size(196, 21);
            this.cmbSelectControl.TabIndex = 39;
            // 
            // btnAddAccountControl
            // 
            this.btnAddAccountControl.BackgroundImage = global::MBAManagementSystem.Properties.Resources.AddUser;
            this.btnAddAccountControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddAccountControl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddAccountControl.Location = new System.Drawing.Point(364, 51);
            this.btnAddAccountControl.Name = "btnAddAccountControl";
            this.btnAddAccountControl.Size = new System.Drawing.Size(22, 19);
            this.btnAddAccountControl.TabIndex = 41;
            this.btnAddAccountControl.UseVisualStyleBackColor = true;
            this.btnAddAccountControl.Click += new System.EventHandler(this.btnAddAccountControl_Click);
            // 
            // frmAccountSubControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 402);
            this.Controls.Add(this.btnAddAccountControl);
            this.Controls.Add(this.btnAddAccountHead);
            this.Controls.Add(this.cmbSelectControl);
            this.Controls.Add(this.btnRefeshControl);
            this.Controls.Add(this.cmbSelectAccountHead);
            this.Controls.Add(this.btnRefreshHead);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvAccountsSubControlsList);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.txtAccountSubControl);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAccountSubControls";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Account Sub Controls";
            this.Load += new System.EventHandler(this.frmAccountSubControls_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ep)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountsSubControlsList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddAccountHead;
        private System.Windows.Forms.ComboBox cmbSelectAccountHead;
        private System.Windows.Forms.ErrorProvider ep;
        private System.Windows.Forms.Button btnAddAccountControl;
        private System.Windows.Forms.ComboBox cmbSelectControl;
        private System.Windows.Forms.Button btnRefeshControl;
        private System.Windows.Forms.Button btnRefreshHead;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvAccountsSubControlsList;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TextBox txtAccountSubControl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
    }
}