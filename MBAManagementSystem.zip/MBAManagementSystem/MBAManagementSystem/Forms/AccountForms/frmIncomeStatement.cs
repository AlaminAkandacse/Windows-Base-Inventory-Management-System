﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmIncomeStatement : Form
    {
        public frmIncomeStatement()
        {
            InitializeComponent();
            dgvIncomeStatement.Columns[0].Width = 180;
        }

        private void IncomeStatement(string financialyearid) 
        {

            dgvIncomeStatement.Rows.Clear();
            // Sales
            string totalsaleincome = "select ISNULL(sum(Credit),0)-ISNULL(sum(Debit),0) from v_Journal where AccountControlID=20 AND FinancialYearID='"+financialyearid+"'";
            DataTable totalsaleincometb = DatabaseAccess.Retrive(totalsaleincome);
            float totalsaleincomevalue = 0;
            if (totalsaleincometb !=null) 
            {
                if (totalsaleincometb.Rows.Count>0) 
                {
                    float.TryParse(Convert.ToString(totalsaleincometb.Rows[0][0]), out totalsaleincomevalue);
                
                }
            
            }
            DataGridViewRow saleincomerow = new DataGridViewRow();
            saleincomerow.CreateCells(dgvIncomeStatement);
            saleincomerow.Cells[0].Value = "Sales";
            //saleoincomerow.Cells[2].Value = totalsaleincometb != null ? (totalsaleincometb.Rows.Count >0 ? (totalsaleincometb.Rows[0][0] !=DBNull.Value ? Convert.ToString(totalsaleincometb.Rows[0][0]) : "0") : "0" ) : "0";
            saleincomerow.Cells[2].Value = totalsaleincomevalue;
            dgvIncomeStatement.Rows.Add(saleincomerow);


            // Cost of Goods Sold
            string totalcostofrevenue = "select ISNULL(sum(Debit),0)-ISNULL(sum(Credit),0) from v_Journal where AccountControlID=13 AND FinancialYearID='" + financialyearid + "'";
            DataTable totalcostofgoodssoldtb = DatabaseAccess.Retrive(totalcostofrevenue);
            float totalcostofgoodssoldvalue = 0;
            if (totalcostofgoodssoldtb != null)
            {
                if (totalcostofgoodssoldtb.Rows.Count > 0)
                {
                    float.TryParse(Convert.ToString(totalcostofgoodssoldtb.Rows[0][0]), out totalcostofgoodssoldvalue);

                }

            }
            DataGridViewRow costofgoodssoldrow = new DataGridViewRow();
            costofgoodssoldrow.CreateCells(dgvIncomeStatement);
            costofgoodssoldrow.Cells[0].Value = "Cost of Goods Sold";
            costofgoodssoldrow.Cells[2].Value = totalcostofgoodssoldvalue;
            dgvIncomeStatement.Rows.Add(costofgoodssoldrow);

            float grossprofitvalue= totalsaleincomevalue - totalcostofgoodssoldvalue;

            DataGridViewRow grossprofitrow = new DataGridViewRow();
            grossprofitrow.CreateCells(dgvIncomeStatement);
            grossprofitrow.Cells[0].Value = "Gross Profit";
            grossprofitrow.Cells[2].Value = grossprofitvalue;
            dgvIncomeStatement.Rows.Add(grossprofitrow);

            //Empty Row
            DataGridViewRow emptyrow = new DataGridViewRow();
            emptyrow.CreateCells(dgvIncomeStatement);
            dgvIncomeStatement.Rows.Add(emptyrow);

            //Operating Expenses Header Title
            DataGridViewRow operatingexpensesrow = new DataGridViewRow();
            operatingexpensesrow.CreateCells(dgvIncomeStatement);
            operatingexpensesrow.Cells[0].Value = "Operating Expenses";
            dgvIncomeStatement.Rows.Add(operatingexpensesrow);


            string operatingexpensesquery = "select AccountControlName,ISNULL(sum(Debit),0)-ISNULL(sum(Credit),0) from v_Journal where AccountControlID=3 AND FinancialYearID='" + financialyearid + "' group by AccountControlName";
            DataTable operatingexpensestb = DatabaseAccess.Retrive(operatingexpensesquery);
            if (operatingexpensestb !=null) 
            {
                if (operatingexpensestb.Rows.Count>0) 
                {
                    foreach (DataRow operatingexpensesaccount in operatingexpensestb.Rows) 
                    {
                        DataGridViewRow operatingexpensesdetailrow = new DataGridViewRow();
                        operatingexpensesdetailrow.CreateCells(dgvIncomeStatement);
                        operatingexpensesdetailrow.Cells[0].Value ="       "+Convert.ToString(operatingexpensesaccount[0]);
                        operatingexpensesdetailrow.Cells[1].Value = Convert.ToString(operatingexpensesaccount[1]);
                        dgvIncomeStatement.Rows.Add(operatingexpensesdetailrow);
                    }
                }
            }

            //Operating Expeses Total
            string totaloperatingexpensquery = "select ISNULL(sum(Debit),0)-ISNULL(sum(Credit),0) from v_Journal where AccountControlID !=13 AND AccountHeadID =3 AND FinancialYearID='" + financialyearid + "'";
            DataTable totaloperatingexpensestb = DatabaseAccess.Retrive(totaloperatingexpensquery);
            float totaloperatingexpensesvalue = 0;
            if (totaloperatingexpensestb != null)
            {
                if (totalcostofgoodssoldtb.Rows.Count > 0)
                {
                    float.TryParse(Convert.ToString(totaloperatingexpensestb.Rows[0][0]), out totaloperatingexpensesvalue);

                }

            }
            DataGridViewRow operatingexpenstotalrow = new DataGridViewRow();
            operatingexpenstotalrow.CreateCells(dgvIncomeStatement);
            operatingexpenstotalrow.Cells[0].Value = "Total Operating Expenses";
            operatingexpenstotalrow.Cells[2].Value = totaloperatingexpensesvalue;
            dgvIncomeStatement.Rows.Add(operatingexpenstotalrow);

            //Empty Row
            DataGridViewRow emptyrow1 = new DataGridViewRow();
            emptyrow1.CreateCells(dgvIncomeStatement);
            dgvIncomeStatement.Rows.Add(emptyrow1);

            //Operating Income
            float operatingincomevalue = grossprofitvalue - totaloperatingexpensesvalue;
            DataGridViewRow operatingincomerow = new DataGridViewRow();
            operatingincomerow.CreateCells(dgvIncomeStatement);
            operatingincomerow.Cells[0].Value = "Operating Income";
            operatingincomerow.Cells[2].Value = operatingincomevalue;
            dgvIncomeStatement.Rows.Add(operatingincomerow);


            //Empty Row
            DataGridViewRow emptyrow2 = new DataGridViewRow();
            emptyrow2.CreateCells(dgvIncomeStatement);
            dgvIncomeStatement.Rows.Add(emptyrow2);

            //Non-Operating Income Header Title
            DataGridViewRow nonoperatingincometitlerow = new DataGridViewRow();
            nonoperatingincometitlerow.CreateCells(dgvIncomeStatement);
            nonoperatingincometitlerow.Cells[0].Value = "Non-Operating Income/Other";
            dgvIncomeStatement.Rows.Add(nonoperatingincometitlerow);

            //Non-Operating Details
            string nonoperatingincomequery = "select AccountCotrolName, ISNULL(sum(Credit),0)-ISNULL(sum(Debit),0) from v_Journal where AccountControlID !=20 AND AccountHeadID =5 AND FinancialYearID='" + financialyearid + "' Group by AccountControlName";
            DataTable nonoperatingincometb = DatabaseAccess.Retrive(nonoperatingincomequery);
            if (nonoperatingincometb != null)
            {
                if (nonoperatingincometb.Rows.Count > 0)
                {
                    foreach (DataRow nonoperatingaccount in nonoperatingincometb.Rows)
                    {
                        DataGridViewRow nonoperatingincomedetailrow = new DataGridViewRow();
                        nonoperatingincomedetailrow.CreateCells(dgvIncomeStatement);
                        nonoperatingincomedetailrow.Cells[0].Value = "       " + Convert.ToString(nonoperatingaccount[0]);
                        nonoperatingincomedetailrow.Cells[2].Value = Convert.ToString(nonoperatingaccount[1]);
                        dgvIncomeStatement.Rows.Add(nonoperatingincomedetailrow);
                    }
                }
            }

            //Non-Operating Total
            string nonoperatingtotalquery = "select ISNULL(sum(Credit),0)-ISNULL(sum(Debit),0) from v_Journal where AccountControlID !=20 AND AccountHeadID =5 AND FinancialYearID='" + financialyearid + "'";
            DataTable nonoperatingtotaltb = DatabaseAccess.Retrive(nonoperatingtotalquery);
            float nonoperatingtotalvalue = 0;
            if (nonoperatingtotaltb != null)
            {
                if (nonoperatingtotaltb.Rows.Count > 0)
                {
                    float.TryParse(Convert.ToString(nonoperatingtotaltb.Rows[0][0]), out nonoperatingtotalvalue);

                }

            }
            DataGridViewRow nonoperatingtotalrow = new DataGridViewRow();
            nonoperatingtotalrow.CreateCells(dgvIncomeStatement);
            nonoperatingtotalrow.Cells[0].Value = "Total Non Operating";
            nonoperatingtotalrow.Cells[2].Value = nonoperatingtotalvalue;
            dgvIncomeStatement.Rows.Add(nonoperatingtotalrow);


            //Empty Row
            DataGridViewRow emptyrow3 = new DataGridViewRow();
            emptyrow3.CreateCells(dgvIncomeStatement);
            dgvIncomeStatement.Rows.Add(emptyrow3);

            //NetIncome Row
            DataGridViewRow netincomerow = new DataGridViewRow();
            netincomerow.CreateCells(dgvIncomeStatement);
            netincomerow.Cells[0].Value = "Net Income";
            netincomerow.Cells[2].Value = operatingincomevalue+ nonoperatingtotalvalue;
            dgvIncomeStatement.Rows.Add(netincomerow);
            SourceCode.GridViewDesign.JournalGridviewDesign(dgvIncomeStatement);
        }
        private void cmbFinancialYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            IncomeStatement(Convert.ToString (cmbFinancialYear .SelectedValue));
        }

       

        private void frmIncomeStatement_Load(object sender, EventArgs e)
        {
            ComboHelper.FillFinancialYear(cmbFinancialYear);
        }
    }
}
