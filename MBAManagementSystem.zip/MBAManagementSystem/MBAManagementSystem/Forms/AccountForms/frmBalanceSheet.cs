﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmBalanceSheet : Form
    {
        public frmBalanceSheet()
        {
            InitializeComponent();
        }

        private void frmBalanceSheet_Load(object sender, EventArgs e)
        {
            ComboHelper.FillFinancialYear(cmbFinancialYear);
        }
    }
}
