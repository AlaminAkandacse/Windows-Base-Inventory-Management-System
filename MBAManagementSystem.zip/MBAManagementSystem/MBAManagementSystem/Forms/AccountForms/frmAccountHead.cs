﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmAccountHead : Form
    {
        public frmAccountHead()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtAccount.Text.Trim().Length==0) 
            {

                ep.SetError(txtAccount,"Please Enter Account Fanilies!");
                txtAccount.Focus();
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from AccountHeadTable where AccountHeadName='"+txtAccount.Text.Trim()+"'");
            if (dt !=null) 
            {
                if (dt.Rows.Count>0) 
                {
                    ep.SetError(txtAccount,"Already Exist");
                    txtAccount.Focus();
                    return;
                }
            }
            string insertquery = string.Format("insert into AccountHeadTable(UserID,AccountHeadName) values('{0}','{1}')",CurrentUser.UserID,txtAccount.Text.Trim());
            bool result = DatabaseAccess.Insert(insertquery);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                txtAccount.Clear();
                FillGrid("");

            }
            else 
            {
                MessageBox.Show("Unexpected Error is occur please contact to concern person");
            }
        
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select * from v_AccountHeadList";
            }
            else
            {
                query = "select * from v_AccountHeadList where ([Account Head]+''+User) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvAccounts.DataSource = dt;
                    dgvAccounts.Columns[0].Width = 100;
                    dgvAccounts.Columns[1].Visible = false;
                    dgvAccounts.Columns[2].Width = 170;
                    dgvAccounts.Columns[3].Width = 120;
                }
                else
                {
                    dgvAccounts.DataSource = null;
                }
            }
            else
            {
                dgvAccounts.DataSource = null;
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAccounts !=null) 
            {
                if (dgvAccounts.Rows.Count > 0)
                {
                    if (dgvAccounts.SelectedRows.Count == 1)
                    {
                        txtAccount.Text = Convert.ToString(dgvAccounts.CurrentRow.Cells[2].Value);
                        EnableComponent();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }

                }
                else 
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }
        private void EnableComponent()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvAccounts.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvAccounts.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtAccount.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAccount.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtAccount.Text.Trim().Length == 0)
            {

                ep.SetError(txtAccount, "Please Enter Account Fanilies!");
                txtAccount.Focus();
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from AccountHeadTable where AccountHeadName='" + txtAccount.Text.Trim() + "' and AccountHeadID='"+dgvAccounts.CurrentRow.Cells[0].Value+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtAccount, "Already Exist");
                    txtAccount.Focus();
                    return;
                }
            }
            string updatetquery = string.Format("update AccountHeadTable set UserID='{0}',AccountHeadName='{1}' where AccountHeadID='{2}'", CurrentUser.UserID, txtAccount.Text.Trim(),dgvAccounts.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(updatetquery);
            if (result)
            {
                MessageBox.Show("Update Successfully");
                DesibleControls();

            }
            else
            {
                MessageBox.Show("Unexpected Error is occur please contact to concern person");
            }
        }

        private void frmAccountHead_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }
    }
}
