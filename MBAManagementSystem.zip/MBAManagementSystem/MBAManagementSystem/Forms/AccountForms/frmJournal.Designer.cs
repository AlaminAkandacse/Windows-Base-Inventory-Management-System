﻿namespace MBAManagementSystem.Forms.AccountForms
{
    partial class frmJournal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.dgvJournal = new System.Windows.Forms.DataGridView();
            this.colTransactionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFYID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFinancialYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAccountHeadID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAccountHeadName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTransactionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInvoiceNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAccountControlID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAccountControlName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAccountSubControlID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDebit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCredit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.paidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJournal)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(968, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // dgvJournal
            // 
            this.dgvJournal.AllowUserToAddRows = false;
            this.dgvJournal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvJournal.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvJournal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvJournal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJournal.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTransactionID,
            this.colFYID,
            this.colFinancialYear,
            this.colAccountHeadID,
            this.colAccountHeadName,
            this.colTransactionDate,
            this.colTitle,
            this.colInvoiceNo,
            this.colAccountControlID,
            this.colAccountControlName,
            this.colAccountSubControlID,
            this.colDebit,
            this.colCredit,
            this.colUser});
            this.dgvJournal.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvJournal.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgvJournal.Location = new System.Drawing.Point(12, 28);
            this.dgvJournal.MultiSelect = false;
            this.dgvJournal.Name = "dgvJournal";
            this.dgvJournal.ReadOnly = true;
            this.dgvJournal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvJournal.Size = new System.Drawing.Size(944, 390);
            this.dgvJournal.TabIndex = 1;
            // 
            // colTransactionID
            // 
            this.colTransactionID.HeaderText = "ID";
            this.colTransactionID.Name = "colTransactionID";
            this.colTransactionID.ReadOnly = true;
            // 
            // colFYID
            // 
            this.colFYID.HeaderText = "FYID";
            this.colFYID.Name = "colFYID";
            this.colFYID.ReadOnly = true;
            this.colFYID.Visible = false;
            // 
            // colFinancialYear
            // 
            this.colFinancialYear.HeaderText = "FinancialYear";
            this.colFinancialYear.Name = "colFinancialYear";
            this.colFinancialYear.ReadOnly = true;
            this.colFinancialYear.Visible = false;
            // 
            // colAccountHeadID
            // 
            this.colAccountHeadID.HeaderText = "Account Head ID";
            this.colAccountHeadID.Name = "colAccountHeadID";
            this.colAccountHeadID.ReadOnly = true;
            this.colAccountHeadID.Visible = false;
            // 
            // colAccountHeadName
            // 
            this.colAccountHeadName.HeaderText = "Account Head";
            this.colAccountHeadName.Name = "colAccountHeadName";
            this.colAccountHeadName.ReadOnly = true;
            this.colAccountHeadName.Visible = false;
            // 
            // colTransactionDate
            // 
            this.colTransactionDate.HeaderText = "Date";
            this.colTransactionDate.Name = "colTransactionDate";
            this.colTransactionDate.ReadOnly = true;
            // 
            // colTitle
            // 
            this.colTitle.HeaderText = "Transaction Title";
            this.colTitle.Name = "colTitle";
            this.colTitle.ReadOnly = true;
            // 
            // colInvoiceNo
            // 
            this.colInvoiceNo.HeaderText = "Invoice No";
            this.colInvoiceNo.Name = "colInvoiceNo";
            this.colInvoiceNo.ReadOnly = true;
            // 
            // colAccountControlID
            // 
            this.colAccountControlID.HeaderText = "Account Control ID";
            this.colAccountControlID.Name = "colAccountControlID";
            this.colAccountControlID.ReadOnly = true;
            // 
            // colAccountControlName
            // 
            this.colAccountControlName.HeaderText = "Account";
            this.colAccountControlName.Name = "colAccountControlName";
            this.colAccountControlName.ReadOnly = true;
            // 
            // colAccountSubControlID
            // 
            this.colAccountSubControlID.HeaderText = "AccountSubControlID";
            this.colAccountSubControlID.Name = "colAccountSubControlID";
            this.colAccountSubControlID.ReadOnly = true;
            this.colAccountSubControlID.Visible = false;
            // 
            // colDebit
            // 
            this.colDebit.HeaderText = "Debit";
            this.colDebit.Name = "colDebit";
            this.colDebit.ReadOnly = true;
            // 
            // colCredit
            // 
            this.colCredit.HeaderText = "Credit";
            this.colCredit.Name = "colCredit";
            this.colCredit.ReadOnly = true;
            // 
            // colUser
            // 
            this.colUser.HeaderText = "User";
            this.colUser.Name = "colUser";
            this.colUser.ReadOnly = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paidToolStripMenuItem,
            this.paymentToolStripMenuItem,
            this.printReceiptToolStripMenuItem,
            this.printInvoiceToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 114);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // paidToolStripMenuItem
            // 
            this.paidToolStripMenuItem.Name = "paidToolStripMenuItem";
            this.paidToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.paidToolStripMenuItem.Text = "Paid Invoice";
            // 
            // paymentToolStripMenuItem
            // 
            this.paymentToolStripMenuItem.Name = "paymentToolStripMenuItem";
            this.paymentToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.paymentToolStripMenuItem.Text = "Invoice Payment";
            // 
            // printReceiptToolStripMenuItem
            // 
            this.printReceiptToolStripMenuItem.Name = "printReceiptToolStripMenuItem";
            this.printReceiptToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.printReceiptToolStripMenuItem.Text = "Print Receipt";
            // 
            // printInvoiceToolStripMenuItem
            // 
            this.printInvoiceToolStripMenuItem.Name = "printInvoiceToolStripMenuItem";
            this.printInvoiceToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.printInvoiceToolStripMenuItem.Text = "Print Invoice";
            // 
            // frmJournal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 430);
            this.Controls.Add(this.dgvJournal);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmJournal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Journal";
            this.Load += new System.EventHandler(this.frmJournal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvJournal)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.DataGridView dgvJournal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransactionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFYID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFinancialYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAccountHeadID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAccountHeadName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransactionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInvoiceNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAccountControlID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAccountControlName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAccountSubControlID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDebit;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCredit;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUser;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem paidToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printReceiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printInvoiceToolStripMenuItem;
    }
}