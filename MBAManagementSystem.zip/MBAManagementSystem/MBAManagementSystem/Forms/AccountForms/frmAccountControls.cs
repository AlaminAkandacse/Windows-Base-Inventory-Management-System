﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmAccountControls : Form
    {
        public frmAccountControls()
        {
            InitializeComponent();
        }


        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select AccountControlID as[ID], AccountHeadID, AccountHeadName as [Account Head], AccountControlName as [Account Control],UserName as [User] from v_AccountControlsList";
            }
            else
            {
                query = "select AccountControlID as[ID], AccountHeadID, AccountHeadName as [Account Head], AccountControlName as [Account Control],UserName as [User] from v_AccountControlsList where ([AccountHeadName]+''+[UserName]+''+AccountControlName) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvAccounts.DataSource = dt;
                    dgvAccounts.Columns[0].Width = 50;
                    dgvAccounts.Columns[1].Visible = false;
                    dgvAccounts.Columns[2].Width = 120;
                    dgvAccounts.Columns[3].Width = 170;
                    dgvAccounts.Columns[4].AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvAccounts.DataSource = null;
                }
            }
            else
            {
                dgvAccounts.DataSource = null;
            }
        }

        private void btnAddAccountHead_Click(object sender, EventArgs e)
        {
            frmAccountHead frm = new frmAccountHead();
            frm.ShowDialog();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillAccountHead(cmbSelectAccountHead);
        }

        private void frmAccountControls_Load(object sender, EventArgs e)
        {
            ComboHelper.FillAccountHead(cmbSelectAccountHead);
            btnRefresh_Click(sender,e);
            FillGrid("");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectAccountHead.SelectedIndex==0) 
            {
                ep.SetError(cmbSelectAccountHead,"Please Select Acoount Head");
                cmbSelectAccountHead.Focus();
                return;
            }

            if (txtAccountControl.Text.Trim().Length == 0)
            {

                ep.SetError(txtAccountControl, "Please Enter Account Control Name!");
                txtAccountControl.Focus();
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from AccountControlTable where AccountControlName='" + txtAccountControl.Text.Trim() + "' and AccountHeadID='"+cmbSelectAccountHead.SelectedValue+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtAccountControl, "Already Exist");
                    txtAccountControl.Focus();
                    return;
                }
            }
            string insertquery = string.Format("insert into AccountControlTable(UserID,AccountHeadID,AccountControlName) values('{0}','{1}','{2}')", CurrentUser.UserID, cmbSelectAccountHead.SelectedValue,txtAccountControl.Text.Trim());
            bool result = DatabaseAccess.Insert(insertquery);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                cmbSelectAccountHead.SelectedIndex = 0;
                txtAccountControl.Clear();
                FillGrid("");

            }
            else
            {
                MessageBox.Show("Unexpected Error is occur please contact to concern person");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAccountControl.Clear();
            cmbSelectAccountHead.SelectedIndex = 0;
        }


        private void EnableComponent()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvAccounts.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvAccounts.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtAccountControl.Clear();
            cmbSelectAccountHead.SelectedIndex = 0;
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectAccountHead.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectAccountHead, "Please Select Acoount Head");
                cmbSelectAccountHead.Focus();
                return;
            }

            if (txtAccountControl.Text.Trim().Length == 0)
            {

                ep.SetError(txtAccountControl, "Please Enter Account Control Name!");
                txtAccountControl.Focus();
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from AccountControlTable where AccountControlName='" + txtAccountControl.Text.Trim() + "' and AccountHeadID='" + cmbSelectAccountHead.SelectedValue + "' and AccountControlID !='"+dgvAccounts.CurrentRow.Cells[0].Value+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtAccountControl, "Already Exist");
                    txtAccountControl.Focus();
                    return;
                }
            }
            string updatequery = string.Format("update  AccountControlTable set UserID='{0}', AccountHeadID='{1}', AccountControlName='{2}' where AccountControlID='{3}'", CurrentUser.UserID, cmbSelectAccountHead.SelectedValue, txtAccountControl.Text.Trim(),dgvAccounts.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(updatequery);
            if (result)
            {
                MessageBox.Show("Update Successfully");
                DesibleControls();
              

            }
            else
            {
                MessageBox.Show("Unexpected Error is occur please contact to concern person");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAccounts != null)
            {
                if (dgvAccounts.Rows.Count > 0)
                {
                    if (dgvAccounts.SelectedRows.Count == 1)
                    {
                        cmbSelectAccountHead.SelectedValue = Convert.ToInt32(dgvAccounts.CurrentRow.Cells[1].Value);
                        txtAccountControl.Text = Convert.ToString(dgvAccounts.CurrentRow.Cells[3].Value);
                        EnableComponent();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }
    }
}
