﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmTrialBalance : Form
    {
        public frmTrialBalance()
        {
            InitializeComponent();
        }

        private void frmTrialBalance_Load(object sender, EventArgs e)
        {
            ComboHelper.FillFinancialYear(cmbFinancialYear);
        }

        private void cmbFinancialYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            string financialyearid = cmbFinancialYear.SelectedValue.ToString();
            string query = " SELECT JR.AccountControlName,JR.FinancialYearID, " +
                           " CASE WHEN JR.Debit>JR.Credit THEN JR.Debit - JR.Credit ELSE NULL END as [Debit], " +
                           " CASE WHEN JR.Debit<JR.Credit THEN JR.Credit - JR.Debit ELSE NULL END as [Credit] FROM " +
                           " (Select AccountControlName, AccountHeadID,FinancialYearID,Sum(Debit) [Debit],Sum(Credit) " +
                           " [Credit] from v_Journal Group by AccountControlName, FinancialYearID, AccountHeadID) JR    WHERE FinancialYearID = '" + financialyearid + "'" +
                           " ORDER BY JR.AccountHeadID ";
                         
            DataTable dt = DatabaseAccess.Retrive(query);
            if (dt !=null) 
            {
                if (dt.Rows.Count>0) 
                {

                    float totalcredit = 0;
                    float totaldebit = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        float creditvalue = 0;
                        float debitvalue = 0;
                        float.TryParse(Convert.ToString(row[2]), out debitvalue);
                        float.TryParse(Convert.ToString(row[3]), out creditvalue);
                        totalcredit = totalcredit + creditvalue;
                        totaldebit = totaldebit + debitvalue;

                    }
                    dt.Rows.Add("Total",financialyearid,totaldebit,totalcredit);
                    //DataGridViewRow totalrow = new DataGridViewRow();
                    //totalrow.CreateCells(dgvTrialBalance);
                    //totalrow.Cells[0].Value = "Total";
                    //totalrow.Cells[2].Value = totaldebit.ToString();
                    //totalrow.Cells[3].Value = totalcredit.ToString();
                    //dgvTrialBalance.Rows.Add(totalrow);

                    dgvTrialBalance.DataSource = dt;
                    dgvTrialBalance.Columns[0].Width = 227;
                    dgvTrialBalance.Columns[1].Visible = false;
                    dgvTrialBalance.Columns[2].Width   = 90;
                    dgvTrialBalance.Columns[3].Width   = 90;
                    GridViewDesign.JournalGridviewDesign(dgvTrialBalance);

                   


                    return;
                
                }
            }
            dgvTrialBalance.DataSource = null;
        }
    }
}
