﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.AccountForms
{
    public partial class frmAccountSubControls : Form
    {
        private string id=string.Empty;

        public frmAccountSubControls()
        {
            InitializeComponent();
        }


        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select AccountSubControlID as[ID], AccountHeadID, AccountHeadName as [Account Head], AccountControlID, AccountControlName as [Account Control], AccountSubControlName as [Sub Control], UserName as [User] from v_AccountSubControlsList";
            }
            else
            {
                query = "select AccountSubControlID as[ID], AccountHeadID, AccountHeadName as [Account Head], AccountControlID, AccountControlName as [Account Control], AccountSubControlName as [Sub Control], UserName as [User] from v_AccountSubControlsList where ([AccountHeadName]+''+[UserName]+''+AccountControlName+''+AccountSubControlName) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvAccountsSubControlsList.DataSource = dt;
                    dgvAccountsSubControlsList.Columns[0].Width = 50;
                    dgvAccountsSubControlsList.Columns[1].Visible = false;
                    dgvAccountsSubControlsList.Columns[2].Width = 120;
                    dgvAccountsSubControlsList.Columns[3].Visible = false;
                    dgvAccountsSubControlsList.Columns[4].Width = 120;
                    dgvAccountsSubControlsList.Columns[5].Width = 120;
                    dgvAccountsSubControlsList.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvAccountsSubControlsList.DataSource = null;
                }
            }
            else
            {
                dgvAccountsSubControlsList.DataSource = null;
            }
        }


        private void btnRefreshHead_Click(object sender, EventArgs e)
        {
            ComboHelper.FillAccountHead(cmbSelectAccountHead);
        }

        private void btnAddAccountHead_Click(object sender, EventArgs e)
        {
            frmAccountHead frm = new frmAccountHead();
            frm.ShowDialog();
        }


        private void EnableComponent()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvAccountsSubControlsList.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvAccountsSubControlsList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            ResetForm();
        }

        private void ResetForm() 
        {
            txtAccountSubControl.Clear();
            cmbSelectAccountHead.SelectedIndex = 0;
        }



        private void btnAddAccountControl_Click(object sender, EventArgs e)
        {
            frmAccountControls frm = new frmAccountControls();
            frm.ShowDialog();
            cmbSelectAccountHead_SelectedIndexChanged(sender,e);
        }

        private void cmbSelectAccountHead_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboHelper.FillAccountHeadControls(cmbSelectControl, cmbSelectAccountHead.SelectedValue);
        }

        private void frmAccountSubControls_Load(object sender, EventArgs e)
        {
            ComboHelper.FillAccountHead(cmbSelectAccountHead);
            FillGrid("");
            
        }

        private void btnRefeshControl_Click(object sender, EventArgs e)
        {
            cmbSelectAccountHead_SelectedIndexChanged(sender, e);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void txtAccountSubControl_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectAccountHead.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectAccountHead, "Please Select Acoount Head");
                cmbSelectAccountHead.Focus();
                return;
            }

            if (cmbSelectControl.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectControl, "Please Select Acoount Control");
                cmbSelectControl.Focus();
                return;
            }

            if (txtAccountSubControl.Text.Trim().Length == 0)
            {

                ep.SetError(txtAccountSubControl, "Please Enter Account Sub Control Name!");
                txtAccountSubControl.Focus();
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from AccountSubControlTable where AccountSubControlName='" + txtAccountSubControl.Text.Trim() + "' and AccountHeadID='" + cmbSelectAccountHead.SelectedValue + "' and AccountControlID='"+cmbSelectControl.SelectedValue+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtAccountSubControl, "Already Exist");
                    txtAccountSubControl.Focus();
                    return;
                }
            }
            string insertquery = string.Format("insert into AccountSubControlTable(AccountHeadID,AccountControlID,UserID,AccountSubControlName) values('{0}','{1}','{2}','{3}')",cmbSelectAccountHead.SelectedValue,cmbSelectControl.SelectedValue,CurrentUser.UserID, txtAccountSubControl.Text.Trim());
            bool result = DatabaseAccess.Insert(insertquery);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                ResetForm();
                FillGrid("");

            }
            else
            {
                MessageBox.Show("Unexpected Error is occur please contact to concern person");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAccountsSubControlsList != null)
            {
                if (dgvAccountsSubControlsList.Rows.Count > 0)
                {
                    if (dgvAccountsSubControlsList.SelectedRows.Count == 1)
                    {
                          id = Convert.ToString(dgvAccountsSubControlsList.CurrentRow.Cells[0].Value);

                        cmbSelectAccountHead.SelectedValue = Convert.ToInt32(dgvAccountsSubControlsList.CurrentRow.Cells[1].Value);
                        cmbSelectControl.SelectedValue = Convert.ToInt32(dgvAccountsSubControlsList.CurrentRow.Cells[3].Value);

                        txtAccountSubControl.Text = Convert.ToString(dgvAccountsSubControlsList.CurrentRow.Cells[5].Value);
                        EnableComponent();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }

                }
                else
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectAccountHead.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectAccountHead, "Please Select Acoount Head");
                cmbSelectAccountHead.Focus();
                return;
            }

            if (cmbSelectControl.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectControl, "Please Select Acoount Control");
                cmbSelectControl.Focus();
                return;
            }

            if (txtAccountSubControl.Text.Trim().Length == 0)
            {

                ep.SetError(txtAccountSubControl, "Please Enter Account Sub Control Name!");
                txtAccountSubControl.Focus();
                return;
            }
            DataTable dt = DatabaseAccess.Retrive("select * from AccountSubControlTable where AccountSubControlName='" + txtAccountSubControl.Text.Trim() + "' and AccountHeadID='" + cmbSelectAccountHead.SelectedValue + "' and AccountControlID='" + cmbSelectControl.SelectedValue + "' and AccountSubControlID !='"+id+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtAccountSubControl, "Already Exist");
                    txtAccountSubControl.Focus();
                    return;
                }
            }
            string updatequery = string.Format("update AccountSubControlTable set AccountHeadID='{0}', AccountControlID='{1}', UserID='{2}',AccountSubControlName='{3}' where AccountSubControlID='{4}'",cmbSelectAccountHead.SelectedValue, cmbSelectControl.SelectedValue, CurrentUser.UserID, txtAccountSubControl.Text.Trim(),id);
            bool result = DatabaseAccess.Update(updatequery);
            if (result)
            {
                MessageBox.Show("Update Successfully");
                DesibleControls();

            }
            else
            {
                MessageBox.Show("Unexpected Error is occur please contact to concern person");
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }
    }
}
