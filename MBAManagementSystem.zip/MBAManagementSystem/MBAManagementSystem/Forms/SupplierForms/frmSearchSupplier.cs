﻿using MBAManagementSystem.Forms.PurchaseForms;
using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.SupplierForms
{
    public partial class frmSearchSupplier : Form
    {
        frmPurchaseForms PurchaseForm;
     private   frmPurchasePayment PurchasePaymentForm;
        public frmSearchSupplier(frmPurchasePayment frmPurchasePayment, string searchvalue)
        {
            InitializeComponent();
            this.PurchasePaymentForm = frmPurchasePayment;
            SupplierCls.GetSupplier(searchvalue, dgvSupplier);
        }

        public frmSearchSupplier(string searchvalue, frmPurchaseForms frmPurchase)
        {
           
            InitializeComponent();
            this.PurchaseForm = frmPurchase;
            SupplierCls.GetSupplier(searchvalue, dgvSupplier);

        
        }



        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            SupplierCls.GetSupplier(txtSearch.Text.Trim(), dgvSupplier);
        }

        private void btnGetAll_Click(object sender, EventArgs e)
        {
            SupplierCls.GetSupplier("", dgvSupplier);
        }

        private void frmSearchSupplier_Load(object sender, EventArgs e)
        {

        }

        private void selectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSupplier !=null) 
            {
                if (dgvSupplier.Rows.Count > 0)
                {
                    if (dgvSupplier.SelectedRows.Count == 1)
                    {
                        if (PurchaseForm != null)
                        {
                            PurchaseForm.selectSupplierid = Convert.ToString(dgvSupplier.CurrentRow.Cells[0].Value);
                            PurchaseForm.lblSupplier.Text = Convert.ToString(dgvSupplier.CurrentRow.Cells[1].Value) + "    Contact No : " + Convert.ToString(dgvSupplier.CurrentRow.Cells[2].Value);
                            this.Close();
                        }

                        else if (PurchasePaymentForm != null)
                        {
                            PurchasePaymentForm.selectsupplierid = Convert.ToString(dgvSupplier.CurrentRow.Cells[0].Value);
                            PurchasePaymentForm.lblSupplier.Text = Convert.ToString(dgvSupplier.CurrentRow.Cells[1].Value) + "    Contact No : " + Convert.ToString(dgvSupplier.CurrentRow.Cells[2].Value);
                            this.Close();
                        }
                    }
                        
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else 
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }
    }

