﻿using CrystalDecisions.Windows.Forms;
using MBAManagementSystem.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.SupplierForms
{
    public partial class frmSupplier : Form
    {
        public frmSupplier()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select SupplierID [ID], SupplierName [Supplier], ContactNo [Contact No], Address,Email, Description from SupplierTable";
            }
            else
            {
                query = "select SupplierID [ID], SupplierName [Supplier], ContactNo [Contact No], Address, Email,Description from SupplierTable where (SupplierName+''+ContactNo+''+Email+''+Address+''+Description) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvSupplierList.DataSource = dt;
                    dgvSupplierList.Columns[0].Width = 100;
                    dgvSupplierList.Columns[1].Width = 100;
                    dgvSupplierList.Columns[2].Width = 100;
                    dgvSupplierList.Columns[3].Width = 100;
                    dgvSupplierList.Columns[4].Width = 200;
                    dgvSupplierList.Columns[5].Width = 200;
                }
                else
                {
                    dgvSupplierList.DataSource = null;
                }
            }
            else
            {
                dgvSupplierList.DataSource = null;
            }

        }


        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvSupplierList.Enabled = false;
            txtSearch.Enabled = false;

        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvSupplierList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            FormClear();

        }

        private void frmSupplier_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            FormClear();
        }

        private void FormClear()
        {
            txtSupplierName.Clear();
            txtContactNo.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtDescription.Clear();

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSupplierList != null)
            {
                if (dgvSupplierList.Rows.Count > 0)
                {
                    if (dgvSupplierList.SelectedRows.Count == 1)
                    {
                        txtSupplierName.Text = Convert.ToString(dgvSupplierList.CurrentRow.Cells[1].Value);
                        txtContactNo.Text = Convert.ToString(dgvSupplierList.CurrentRow.Cells[2].Value);
                        txtAddress.Text = Convert.ToString(dgvSupplierList.CurrentRow.Cells[3].Value);
                        txtEmail.Text = Convert.ToString(dgvSupplierList.CurrentRow.Cells[4].Value);
                        txtDescription.Text = Convert.ToString(dgvSupplierList.CurrentRow.Cells[5].Value);
     
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty");
                }


            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtSupplierName.Text.Trim().Length == 0)
            {
                ep.SetError(txtSupplierName, "Please Enter Supplier Name!");
                txtSupplierName.Focus();
                return;
            }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please Enter Contact No!");
                txtContactNo.Focus();
                return;
            }

            if (txtAddress.Text.Trim().Length == 0)
            {
                ep.SetError(txtAddress, "Please Enter Address!");
                txtAddress.Focus();
                return;
            }

            if (txtEmail.Text.Trim().Length == 0)
            {
                ep.SetError(txtEmail, "Please Enter Email!");
                txtEmail.Focus();
                return;
            }

            if (txtDescription.Text.Trim().Length == 0)
            {
                ep.SetError(txtDescription, "Please Enter Description!");
                txtDescription.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from SupplierTable where ContactNo='" + txtContactNo.Text.Trim() + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtContactNo, "Already Exist!");
                    txtContactNo.Focus();
                    return;
                }
            }


            string query = string.Format("insert into SupplierTable(SupplierName,ContactNo,Address,Email,Description) values('{0}','{1}','{2}','{3}','{4}')", txtSupplierName.Text.Trim(),txtContactNo.Text.Trim(),txtAddress.Text.Trim(),txtEmail.Text.Trim(),txtDescription.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                FillGrid("");
                FormClear();
            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtSupplierName.Text.Trim().Length == 0)
            {
                ep.SetError(txtSupplierName, "Please Enter Supplier Name!");
                txtSupplierName.Focus();
                return;
            }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please Enter Contact No!");
                txtContactNo.Focus();
                return;
            }

            if (txtAddress.Text.Trim().Length == 0)
            {
                ep.SetError(txtAddress, "Please Enter Address!");
                txtAddress.Focus();
                return;
            }

            if (txtEmail.Text.Trim().Length == 0)
            {
                ep.SetError(txtEmail, "Please Enter Email!");
                txtEmail.Focus();
                return;
            }

            if (txtDescription.Text.Trim().Length == 0)
            {
                ep.SetError(txtDescription, "Please Enter Description!");
                txtDescription.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from SupplierTable where ContactNo='" + txtContactNo.Text.Trim() + "' and SupplierID !='"+dgvSupplierList.CurrentRow.Cells[0].Value+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtContactNo, "Already Exist!");
                    txtContactNo.Focus();
                    return;
                }
            }


            string updatequery = string.Format("update  SupplierTable set SupplierName='{0}', ContactNo='{1}', Address='{2}', Email='{3}', Description='{4}' where SupplierID='{5}'", txtSupplierName.Text.Trim(), txtContactNo.Text.Trim(), txtAddress.Text.Trim(), txtEmail.Text.Trim(), txtDescription.Text.Trim(),dgvSupplierList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(updatequery);
            if (result)
            {
                MessageBox.Show("Update Successfully");
                FillGrid("");
                DesibleControls();
                
            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            frmPrintSupplierList frm = new frmPrintSupplierList();
            frm.ShowDialog();
        }


    }
}
