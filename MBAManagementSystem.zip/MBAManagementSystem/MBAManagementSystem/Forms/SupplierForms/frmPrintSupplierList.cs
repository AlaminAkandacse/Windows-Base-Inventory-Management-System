﻿using MBAManagementSystem.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.SupplierForms
{
    public partial class frmPrintSupplierList : Form
    {
        public frmPrintSupplierList()
        {
            InitializeComponent();
        }

        private void frmPrintSupplierList_Load(object sender, EventArgs e)
        {
            rpt_PrintSupplierList rpt = new rpt_PrintSupplierList();
            rpt.Refresh();
            crv.ReportSource = rpt;
        }
    }
}
