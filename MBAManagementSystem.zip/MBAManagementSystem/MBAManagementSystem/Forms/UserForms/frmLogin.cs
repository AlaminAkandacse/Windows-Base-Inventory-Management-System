﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.UserForms
{
    public partial class frmLogin : Form
    {
        private frmMainForm MainForm;

        public frmLogin()
        {
            InitializeComponent();
        }

        public frmLogin(frmMainForm frmmainForm)
        {
            // Tooo: Complete member initialization
            InitializeComponent();
            this.MainForm = frmmainForm;
        }

        private void txtLogin_Click(object sender, EventArgs e)
        {
            lblError.Visible = false;
            ep.Clear();
            if (txtUserName.Text.Trim().Length==0) 
            {
                ep.SetError(txtUserName,"Please Enter User Name!");
                txtUserName.Focus();
                return;
            }

            if (txtPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtPassword, "Please Enter Password!");
                txtPassword.Focus();
                return;
            }
            string getquery = "select UserID, UserTypeID,FullName, Email,ContactNo,UserName from UsersTable where UserName='"+txtUserName.Text.Trim()+"' and Password='"+txtPassword.Text.Trim()+"'";
            DataTable dt = DatabaseAccess.Retrive(getquery);
            if (dt == null)
            {
                lblError.Visible = true;
                MainForm.tsbLogin.Visible = true;
                MainForm.tsbLogout.Visible = false;
                MainForm.msall.Enabled = false;
                return;
            }
            else if (dt.Rows.Count > 0)
            {
                // Visible Control
                MainForm.tsbLogin.Visible = false;
                MainForm.tsbLogout.Visible = true;
                MainForm.msall.Enabled = true;
                CurrentUser.UserID=Convert.ToInt32(dt.Rows[0]["UserID"]);
                CurrentUser.UserTypeID = Convert.ToInt32(dt.Rows[0]["UserTypeID"]);
                CurrentUser.FullName = Convert.ToString(dt.Rows[0]["FullName"]);
                CurrentUser.Email = Convert.ToString(dt.Rows[0]["Email"]);
                CurrentUser.ContactNo = Convert.ToString(dt.Rows[0]["ContactNo"]);
                CurrentUser.UserName = Convert.ToString(dt.Rows[0]["UserName"]);
                this.Close();
                return;
            }
            else 
            {
                lblError.Visible = true;
            }
         

        }
    }
}
