﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem
{
    public partial class frmUserTypes : Form
    {
        public frmUserTypes()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue) 
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select UserTypeID [ID], UserType [User Type] from UserTypesTable";
            }
            else 
            {
                query = "select UserTypeID [ID], UserType [User Type] from UserTypesTable where UserType like '%"+searchvalue+"%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvUserType.DataSource = dt;
                    dgvUserType.Columns[0].Width = 100;
                    dgvUserType.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvUserType.DataSource = null;
                }
            }
            else 
            {
                dgvUserType.DataSource = null;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtEnterUserType.Text.Trim().Length==0) 
            {
                ep.SetError(txtEnterUserType,"Please Enter User Type!");
                txtEnterUserType.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from UserTypesTable where UserType='"+txtEnterUserType.Text.Trim()+"'");
            if (dt != null) 
            {
                if (dt.Rows.Count>0) 
                {
                    ep.SetError(txtEnterUserType,"Already Exist!");
                    txtEnterUserType.Focus();
                    return;
                }
            }


            string query = string.Format("insert into UserTypesTable(UserType) values('{0}')",txtEnterUserType.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                FillGrid("");
            }
            else 
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void frmUserTypes_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEnterUserType.Clear();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvUserType !=null) 
            {
                if (dgvUserType.Rows.Count > 0)
                {
                    if (dgvUserType.SelectedRows.Count == 1)
                    {
                        txtEnterUserType.Text = Convert.ToString(dgvUserType.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else 
                {
                    MessageBox.Show("List is Empty");
                }

            
            }
        }

        private void EnableControls() 
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvUserType.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvUserType.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtEnterUserType.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtEnterUserType.Text.Trim().Length == 0)
            {
                ep.SetError(txtEnterUserType, "Please Enter User Type!");
                txtEnterUserType.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from UserTypesTable where UserType='" + txtEnterUserType.Text.Trim() + "' and UserTypeID !='"+ Convert.ToString(dgvUserType.CurrentRow.Cells[0].Value) + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtEnterUserType, "Already Exist!");
                    txtEnterUserType.Focus();
                    return;
                }
            }

            string query = string.Format("update  UserTypesTable set UserType='{0}' where UserTypeID = '{1}'", txtEnterUserType.Text.Trim(),Convert.ToString (dgvUserType.CurrentRow.Cells[0].Value));
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated Successfully");
                FillGrid("");
                DesibleControls();
            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvUserType != null)
            {
                if (dgvUserType.Rows.Count > 0)
                {
                    if (dgvUserType.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you Sure you want to delete Selected Record!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            bool result= DatabaseAccess.Delete("delete from UserTypesTable where UserTypeID='" + dgvUserType.CurrentRow.Cells[0].Value + "'");
                            if (result)
                            {
                                MessageBox.Show("Deleted Successfully");
                                FillGrid("");
             
                            }
                            else 
                            {
                                MessageBox.Show("Some Record are depended! other Contact to Concern oerson.");
                            }
                        }

                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty");
                }


            }
        }
    }
}
