﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.UserForms
{
    public partial class frmAddUsers : Form
    {
        public frmAddUsers()
        {
            InitializeComponent();
        }

        private void frmAddUsers_Load(object sender, EventArgs e)
        {
            ComboHelper.FillUserTypes(cmbSelectUserType);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillUserTypes(cmbSelectUserType);
        }

        private void btnAddUserType_Click(object sender, EventArgs e)
        {
            frmUserTypes frm = new frmUserTypes();
            frm.ShowDialog();
            btnRefresh_Click(sender, e);
        }


        private void ClearForm() 
        {
            cmbSelectUserType.SelectedIndex = 0;
            txtEmail.Clear();
            txtContactNo.Clear();
            txtFullName.Clear();
            txtPassword.Clear();
            txtUserName.Clear();
            txtConfirmPassword.Clear();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectUserType.SelectedIndex==0) 
            {
                ep.SetError(cmbSelectUserType,"Please Select user Type!");
                cmbSelectUserType.Focus();
                return;
            }
            if (txtFullName.Text.Trim().Length==0) 
            {
                ep.SetError(txtFullName, "Please Enter Full Name");
                txtFullName.Focus();
                return;
            }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please Enter Contact No");
                txtContactNo.Focus();
                return;
            }

            if (txtUserName.Text.Trim().Length == 0)
            {
                ep.SetError(txtUserName, "Please Enter User Name");
                txtUserName.Focus();
                return;
            }

            if (txtUserName.Text.Trim().Length == 0)
            {
                ep.SetError(txtUserName, "Please Enter User Name");
                txtUserName.Focus();
                return;
            }

            if (txtPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtPassword, "Please Enter Password");
                txtPassword.Focus();
                return;
            }

            if (txtConfirmPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtConfirmPassword, "Please Enter Re-enter Password");
                txtConfirmPassword.Focus();
                return;
            }
            if (txtPassword.Text.Trim() !=txtConfirmPassword.Text.Trim()) 
            {
                ep.SetError(txtConfirmPassword,"No Match");
                txtConfirmPassword.Focus();
                return;
            
            }
         
            DataTable dt = DatabaseAccess.Retrive("select * from UsersTable where UserName='"+txtUserName+"'");
            if (dt !=null) 
            {
                if (dt.Rows.Count>0) 
                {
                    ep.SetError(txtUserName,"User Name Already Exist");
                    txtUserName.Focus();
                    return;
                }
            }
            dt = null;
             dt = DatabaseAccess.Retrive("select * from UsersTable where FullName='" + txtFullName.Text.Trim() + "' and ContactNo='"+txtContactNo.Text.Trim()+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtFullName, "User Already Registered");
                    txtFullName.Focus();
                    return;
                }
            }

            string insertquery = string.Format("insert into UsersTable(UserTypeID,FullName,Email,ContactNo,UserName,Password) values('{0}','{1}','{2}','{3}','{4}','{5}')",cmbSelectUserType.SelectedValue,txtFullName.Text.Trim(),txtEmail.Text.Trim(),txtContactNo.Text.Trim(),txtUserName.Text.Trim(),txtPassword.Text.Trim());
            bool result = DatabaseAccess.Insert(insertquery);
            if (result)
            {
                MessageBox.Show("User Register Successfully");
                this.Close();

            }
            else 
            {
                MessageBox.Show("Un-Expected Error is Occured Please Contact to Concern person");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }
    }
}
