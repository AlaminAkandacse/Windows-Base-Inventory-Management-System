﻿using MBAManagementSystem.Forms.SupplierForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.PurchaseForms
{
    public partial class frmPurchasePayment : Form
    {

        //DataTable dtEntries;
        public string selectsupplierid = string.Empty;
        public frmPurchasePayment()
        {
            InitializeComponent();
        }

        private void GetAllUnPaidPurchasesInvoice()
        {
            try
            {
                if (string.IsNullOrEmpty(selectsupplierid))
            {
                dgvPurchases.DataSource = null;
                return;
            }
            string query = "SELECT AP.SupplierInvoiceID [ID],AP.SupplierID [SupplierID],AP.SupplierName [Supplier],AP.InvoiceNo [Invoice No]," +
                " AP.InvoiceDate [Date],AP.Title [Title],AP.TotalAmount [Total Amount],(AP.TotalAmount - ISNULL(SPT.Payment,0)) as [Remaining Payment] " +
                " ,AP.UserName [User],Description FROM v_AllPurchases AP LEFT JOIN (select SupplierInvoiceID, sum(PaymentAmount) " +
                " as [Payment] from SupplierPaymentTable group by SupplierInvoiceID) SPT ON AP.SupplierInvoiceID = SPT.SupplierInvoiceID " +
                " where AP.TotalAmount > isnull(SPT.Payment,0) AND AP.SupplierID = '" + selectsupplierid + "'";
            DataTable dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvPurchases.DataSource = dt;
                    dgvPurchases.Columns[0].Visible = false;//ID
                    dgvPurchases.Columns[1].Visible = false;//Supplier ID
                    dgvPurchases.Columns[2].Visible = false;//SupplierName
                    dgvPurchases.Columns[3].Width = 150;//InvoiceNo
                    dgvPurchases.Columns[4].Width = 120;//InvoiceDate
                    dgvPurchases.Columns[5].Visible = false;//Title
                    dgvPurchases.Columns[6].Width = 120;//TotalAmount
                    dgvPurchases.Columns[7].Width = 120;//Remaining Amount
                    dgvPurchases.Columns[8].Width = 80;//UserName
                    dgvPurchases.Columns[9].Width = 230;//Description
                    CalculateReaminingPayment();
                    return;
                }
            }
            dgvPurchases.DataSource = null;
            CalculateReaminingPayment();

            }
            catch (Exception)
            {
                dgvPurchases.DataSource = null;
                MessageBox.Show("Unexpectted Error id Occur Please Contact to Concern Person!");
            }


        }


        private void CalculateReaminingPayment()
        {
            float totalpayment = 0;
            if (dgvPurchases != null)
            {
                if (dgvPurchases.Rows.Count > 0)
                {
                    foreach (DataGridViewRow item in dgvPurchases.Rows)
                    {
                        float payment = 0;
                        float.TryParse(Convert.ToString(item.Cells[7].Value), out payment);
                        totalpayment = totalpayment + payment;
                    }

                }
            }
            lblRemainingPayment.Text = Convert.ToString(totalpayment);
        }

        private void btnSearchSupplier_Click(object sender, EventArgs e)
        {
            frmSearchSupplier frm = new frmSearchSupplier(this,txtSearch.Text.Trim());
            frm.ShowDialog();
            GetAllUnPaidPurchasesInvoice();
           

        }
        private void btnAddSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier frm = new frmSupplier();
            frm.ShowDialog();
        }

        private void dgvPurchases_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void frmPurchasePayment_Load(object sender, EventArgs e)
        {
           
        }

        private void btnPanelClose_Click(object sender, EventArgs e)
        {

            panelPayment.Visible = false;
            dgvPurchases.Enabled = true;

        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            if (dgvPurchases != null)
            {
                if (dgvPurchases.Rows.Count > 0)
                {
                    if (dgvPurchases.SelectedRows.Count == 1)
                    {
                        dgvPurchases.Enabled = false;
                        float payment = 0;
                        panelPayment.Visible = true;

                        foreach (DataGridViewRow item in dgvPurchases.Rows)
                        {
                            if (item.Selected == true)
                            {
                                float.TryParse(Convert.ToString(item.Cells[7].Value), out payment);

                            }
                        }

                        txtTotalPayment.Text = Convert.ToString(payment);
                    }
                    else if (dgvPurchases.SelectedRows.Count > 1)
                    {
                        dgvPurchases.Enabled = true;
                        panelPayment.Visible = false;

                        //multiple Payment
                        PurchasesPayments();

                    }

                }
            }
        }

        private void PurchasesPayments() 
        {


            if (dgvPurchases.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please Select  Invoice!");
                return;
            }

            foreach (DataGridViewRow item in dgvPurchases.Rows)
            {



                float totalpurchaseamount = 0;
                float totalpaymentamount = 0;

                string invoiceno = string.Empty;
                //float totalremainingamount = 0;

                if (item.Selected == true)
                    {
                        float.TryParse(Convert.ToString(item.Cells[6].Value), out totalpurchaseamount);
                        float.TryParse(Convert.ToString(item.Cells[7].Value), out totalpaymentamount);
                    invoiceno = Convert.ToString(item.Cells[0].Value);
                }
                

                //float.TryParse(txtEnterPayment.Text.Trim(), out totalpaymentamount);
                //float.TryParse(txtRemainingPayment.Text.Trim(), out totalremainingamount);

                string FinancialYearID = (DatabaseAccess.Retrive("select top 1 FinancialYearID from FinancialYearTable where IsActive=1") != null ? Convert.ToString(DatabaseAccess.Retrive("select top 1 financialYearID from FinancialYearTable where IsActive=1").Rows[0][0]) : string.Empty);

                string payinvoiceno = "PAY" + DateTime.Now.ToString("ddMMyyyyHHmmssmm");
                string transactiontitle = "Payment Paid to " + lblSupplier.Text.Trim();
                string creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                  FinancialYearID, "1", "1", "0", payinvoiceno, CurrentUser.UserID, totalpaymentamount, "0", DateTime.Now, transactiontitle);

                transactiontitle = lblSupplier.Text.Trim() + ", Purchase Payment is Succesed";
                string debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                  FinancialYearID, "2", "3", "0", payinvoiceno, CurrentUser.UserID, "0", totalpaymentamount, DateTime.Now, transactiontitle);

                DatabaseAccess.Insert(creditquery);
                DatabaseAccess.Insert(debittquery);

                //string invoiceno = string.Empty;
                //foreach (DataGridViewRow row in dgvPurchases.Rows)
                //{
                //    if (item.Selected == true)
                //    {
                //        invoiceno = Convert.ToString(row.Cells[0].Value);

                //    }
                //}

                string paymentquery = string.Format("insert into SupplierPaymentTable(SupplierID,SupplierInvoiceID,UserID,InvoiceNo,TotalAmount,PaymentAmount,RemainingBalance) " +
               " values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}')",
                selectsupplierid, invoiceno, CurrentUser.UserID, payinvoiceno, totalpurchaseamount, totalpaymentamount, "0");

                DatabaseAccess.Insert(paymentquery);
                Thread.Sleep(1000);
            }
            MessageBox.Show("All Payments Successfull");
            //dgvPurchases.Enabled = true;
            panelPayment.Visible = false;
            GetAllUnPaidPurchasesInvoice();

        }

        private void txtEnterPayment_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }



     //private void SetEntries(string FinancialYearID,
     //string AccountHeadID,
     //string AccountControlID,
     //string AccountSubControlID,
     //string InvoiceNo,
     //string UserID,
     //string Credit,
     //string Debit,
     //DateTime TransactionDate,
     //string TransactionTitle)
     //   {
     //       if (dtEntries == null)
     //       {
     //           dtEntries = new DataTable();
     //           dtEntries.Columns.Add("FinancialYearID");
     //           dtEntries.Columns.Add("AccountHeadID");
     //           dtEntries.Columns.Add("AccountControlID");
     //           dtEntries.Columns.Add("AccountSubControlID");
     //           dtEntries.Columns.Add("UserID");
     //           dtEntries.Columns.Add("Credit");
     //           dtEntries.Columns.Add("Debit");
     //           dtEntries.Columns.Add("TransactionDate");
     //           dtEntries.Columns.Add("TransactionTitle");
     //       }


     //       if (dtEntries != null)
     //       {
     //           if (dtEntries.Rows.Count > 0)
     //           {
     //               dtEntries.Rows.Add(FinancialYearID,
     //               AccountHeadID,
     //               AccountControlID,
     //               AccountSubControlID,
     //               InvoiceNo,
     //               UserID,
     //               Credit,
     //               Debit,
     //               TransactionDate,
     //               TransactionTitle);
     //           }
     //           else
     //           {
     //               bool isupdated = false;
     //               foreach (DataRow item in dtEntries.Rows)
     //               {
     //                   decimal creditvalue = 0;
     //                   decimal debitvalue = 0;
     //                   decimal.TryParse(Convert.ToString(item[6]).Trim(), out creditvalue);
     //                   decimal.TryParse(Convert.ToString(item[7]).Trim(), out debitvalue);

     //                   if (Convert.ToString(item[1]).Trim() == AccountHeadID.Trim() &&
     //                       Convert.ToString(item[2]).Trim() == AccountControlID.Trim() &&
     //                       Convert.ToString(item[3]).Trim() == AccountSubControlID.Trim() &&

     //                       creditvalue > 0)
     //                   {
     //                       item[6] = (creditvalue + Convert.ToDecimal(Credit));
     //                       isupdated = true;
     //                   }
     //                   else if (Convert.ToString(item[1]).Trim() == AccountHeadID.Trim() &&
     //                       Convert.ToString(item[2]).Trim() == AccountControlID.Trim() &&
     //                       Convert.ToString(item[3]).Trim() == AccountSubControlID.Trim() &&

     //                       debitvalue > 0)
     //                   {

     //                       item[7] = (debitvalue + Convert.ToDecimal(Debit));
     //                       isupdated = true;
     //                   }
     //                   //else 
     //                   //{

     //                   //    dtEntries.Rows.Add(
     //                   //    FinancialYearID,
     //                   //    AccountHeadID,
     //                   //    AccountControlID,
     //                   //    AccountSubControlID,
     //                   //    InvoiceNo,
     //                   //    UserID,
     //                   //    Credit,
     //                   //    Debit,
     //                   //    TransactionDate,
     //                   //    TransactionTitle);

     //                   //}
     //               }

     //               if (isupdated == true)
     //               {
     //                   dtEntries.Rows.Add(FinancialYearID,
     //                   AccountHeadID,
     //                   AccountControlID,
     //                   AccountSubControlID,
     //                   InvoiceNo,
     //                   UserID,
     //                   Credit,
     //                   Debit,
     //                   TransactionDate,
     //                   TransactionTitle);
     //               }

     //           }
     //       }
     //   }



        private void txtEnterPayment_TextChanged(object sender, EventArgs e)
        {
            float remainingpayment = 0;
            float totalpurchaseamount = 0;
            float.TryParse(txtTotalPayment.Text.Trim(), out totalpurchaseamount);
            float.TryParse(txtEnterPayment.Text.Trim(), out remainingpayment);
            txtRemainingPayment.Text = (totalpurchaseamount - remainingpayment).ToString();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            if (dgvPurchases.SelectedRows.Count !=1) 
            {
                MessageBox.Show("Please Select one Invoice!");
                return;
            }
            float totalpurchaseamount = 0;
            float totalpaymentamount = 0;
            float totalremainingamount = 0;
            foreach (DataGridViewRow item in dgvPurchases.Rows)
            {
                if (item.Selected == true)
                {
                    float.TryParse(Convert.ToString(item.Cells[6].Value), out totalpurchaseamount);

                }
            }
           
            float.TryParse(txtEnterPayment.Text.Trim(), out totalpaymentamount);
            float.TryParse(txtRemainingPayment.Text.Trim(), out totalremainingamount);

            string FinancialYearID = (DatabaseAccess.Retrive("select top 1 FinancialYearID from FinancialYearTable where IsActive=1") != null ? Convert.ToString(DatabaseAccess.Retrive("select top 1 financialYearID from FinancialYearTable where IsActive=1").Rows[0][0]) : string.Empty);

            string payinvoiceno = "PAY" + DateTime.Now.ToString("ddMMyyyyHHmmssmm");
            string transactiontitle = "Payment Paid to " + lblSupplier.Text.Trim();
            string creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
              FinancialYearID, "1", "1", "0", payinvoiceno, CurrentUser.UserID, totalpaymentamount, "0", DateTime.Now, transactiontitle);

            transactiontitle = lblSupplier.Text.Trim() + ", Purchase Payment is Succesed";
            string debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
              FinancialYearID, "2", "3", "0", payinvoiceno, CurrentUser.UserID, "0", totalpaymentamount, DateTime.Now, transactiontitle);

            DatabaseAccess.Insert(creditquery);
            DatabaseAccess.Insert(debittquery);

            string invoiceno = string.Empty;
            foreach (DataGridViewRow item in dgvPurchases.Rows)
            {
                if (item.Selected == true)
                {
                    invoiceno = Convert.ToString(item.Cells[0].Value);

                }
            }

            string paymentquery = string.Format("insert into SupplierPaymentTable(SupplierID,SupplierInvoiceID,UserID,InvoiceNo,TotalAmount,PaymentAmount,RemainingBalance) " +
           " values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}')",
            selectsupplierid, invoiceno, CurrentUser.UserID, payinvoiceno, totalpurchaseamount, totalpaymentamount, totalremainingamount);

            DatabaseAccess.Insert(paymentquery);

            MessageBox.Show("Payment Successfull");
            dgvPurchases.Enabled = true;
            panelPayment.Visible = false;
            GetAllUnPaidPurchasesInvoice();

        }
    }
}
