﻿namespace MBAManagementSystem.Forms.PurchaseForms
{
    partial class frmPurchasePayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.grpSupplier = new System.Windows.Forms.GroupBox();
            this.btnAddSupplier = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvPurchases = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.paymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label4 = new System.Windows.Forms.Label();
            this.lblRemainingPayment = new System.Windows.Forms.Label();
            this.panelPayment = new System.Windows.Forms.Panel();
            this.btnPayment = new System.Windows.Forms.Button();
            this.txtRemainingPayment = new System.Windows.Forms.TextBox();
            this.txtEnterPayment = new System.Windows.Forms.TextBox();
            this.txtTotalPayment = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnPanelClose = new System.Windows.Forms.Button();
            this.btnSearchSupplier = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.grpSupplier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPurchases)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.panelPayment.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(732, 55);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(181, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Purchase Payment";
            // 
            // grpSupplier
            // 
            this.grpSupplier.Controls.Add(this.btnAddSupplier);
            this.grpSupplier.Controls.Add(this.btnSearchSupplier);
            this.grpSupplier.Controls.Add(this.txtSearch);
            this.grpSupplier.Controls.Add(this.lblSupplier);
            this.grpSupplier.Controls.Add(this.label3);
            this.grpSupplier.Controls.Add(this.label2);
            this.grpSupplier.Location = new System.Drawing.Point(12, 61);
            this.grpSupplier.Name = "grpSupplier";
            this.grpSupplier.Size = new System.Drawing.Size(305, 93);
            this.grpSupplier.TabIndex = 2;
            this.grpSupplier.TabStop = false;
            this.grpSupplier.Text = "Select  Supplier";
            // 
            // btnAddSupplier
            // 
            this.btnAddSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSupplier.Location = new System.Drawing.Point(275, 20);
            this.btnAddSupplier.Name = "btnAddSupplier";
            this.btnAddSupplier.Size = new System.Drawing.Size(24, 20);
            this.btnAddSupplier.TabIndex = 3;
            this.btnAddSupplier.Text = "*";
            this.btnAddSupplier.UseVisualStyleBackColor = true;
            this.btnAddSupplier.Click += new System.EventHandler(this.btnAddSupplier_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(102, 20);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(148, 20);
            this.txtSearch.TabIndex = 1;
            // 
            // lblSupplier
            // 
            this.lblSupplier.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSupplier.Location = new System.Drawing.Point(97, 57);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(202, 23);
            this.lblSupplier.TabIndex = 0;
            this.lblSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Select Supplier :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Search Supplier :";
            // 
            // dgvPurchases
            // 
            this.dgvPurchases.AllowUserToAddRows = false;
            this.dgvPurchases.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvPurchases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvPurchases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPurchases.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvPurchases.Location = new System.Drawing.Point(12, 160);
            this.dgvPurchases.Name = "dgvPurchases";
            this.dgvPurchases.ReadOnly = true;
            this.dgvPurchases.RowHeadersVisible = false;
            this.dgvPurchases.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPurchases.Size = new System.Drawing.Size(708, 307);
            this.dgvPurchases.TabIndex = 43;
            this.dgvPurchases.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPurchases_CellContentClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paymentToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(122, 26);
            // 
            // paymentToolStripMenuItem
            // 
            this.paymentToolStripMenuItem.Name = "paymentToolStripMenuItem";
            this.paymentToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.paymentToolStripMenuItem.Text = "Payment";
            this.paymentToolStripMenuItem.Click += new System.EventHandler(this.paymentToolStripMenuItem_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(444, 479);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 13);
            this.label4.TabIndex = 44;
            this.label4.Text = "Total Remaining Payment :";
            // 
            // lblRemainingPayment
            // 
            this.lblRemainingPayment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRemainingPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemainingPayment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblRemainingPayment.Location = new System.Drawing.Point(584, 470);
            this.lblRemainingPayment.Name = "lblRemainingPayment";
            this.lblRemainingPayment.Size = new System.Drawing.Size(136, 31);
            this.lblRemainingPayment.TabIndex = 44;
            this.lblRemainingPayment.Text = "0.0";
            this.lblRemainingPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelPayment
            // 
            this.panelPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelPayment.Controls.Add(this.btnPayment);
            this.panelPayment.Controls.Add(this.txtRemainingPayment);
            this.panelPayment.Controls.Add(this.txtEnterPayment);
            this.panelPayment.Controls.Add(this.txtTotalPayment);
            this.panelPayment.Controls.Add(this.btnPanelClose);
            this.panelPayment.Controls.Add(this.label7);
            this.panelPayment.Controls.Add(this.label6);
            this.panelPayment.Controls.Add(this.label5);
            this.panelPayment.Location = new System.Drawing.Point(198, 146);
            this.panelPayment.Name = "panelPayment";
            this.panelPayment.Size = new System.Drawing.Size(317, 208);
            this.panelPayment.TabIndex = 46;
            this.panelPayment.Visible = false;
            // 
            // btnPayment
            // 
            this.btnPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPayment.Location = new System.Drawing.Point(237, 172);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(62, 23);
            this.btnPayment.TabIndex = 2;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // txtRemainingPayment
            // 
            this.txtRemainingPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemainingPayment.Location = new System.Drawing.Point(137, 142);
            this.txtRemainingPayment.Name = "txtRemainingPayment";
            this.txtRemainingPayment.ReadOnly = true;
            this.txtRemainingPayment.Size = new System.Drawing.Size(163, 23);
            this.txtRemainingPayment.TabIndex = 1;
            // 
            // txtEnterPayment
            // 
            this.txtEnterPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnterPayment.Location = new System.Drawing.Point(137, 93);
            this.txtEnterPayment.Name = "txtEnterPayment";
            this.txtEnterPayment.Size = new System.Drawing.Size(163, 23);
            this.txtEnterPayment.TabIndex = 1;
            this.txtEnterPayment.TextChanged += new System.EventHandler(this.txtEnterPayment_TextChanged);
            this.txtEnterPayment.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnterPayment_KeyPress);
            // 
            // txtTotalPayment
            // 
            this.txtTotalPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalPayment.Location = new System.Drawing.Point(137, 44);
            this.txtTotalPayment.Name = "txtTotalPayment";
            this.txtTotalPayment.ReadOnly = true;
            this.txtTotalPayment.Size = new System.Drawing.Size(163, 23);
            this.txtTotalPayment.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Remaining Payment : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Enter Payment : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Purchase Payment : ";
            // 
            // btnPanelClose
            // 
            this.btnPanelClose.BackgroundImage = global::MBAManagementSystem.Properties.Resources.Deletion;
            this.btnPanelClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPanelClose.Location = new System.Drawing.Point(289, -1);
            this.btnPanelClose.Name = "btnPanelClose";
            this.btnPanelClose.Size = new System.Drawing.Size(27, 23);
            this.btnPanelClose.TabIndex = 0;
            this.btnPanelClose.UseVisualStyleBackColor = true;
            this.btnPanelClose.Click += new System.EventHandler(this.btnPanelClose_Click);
            // 
            // btnSearchSupplier
            // 
            this.btnSearchSupplier.BackgroundImage = global::MBAManagementSystem.Properties.Resources.src;
            this.btnSearchSupplier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSearchSupplier.Location = new System.Drawing.Point(250, 20);
            this.btnSearchSupplier.Name = "btnSearchSupplier";
            this.btnSearchSupplier.Size = new System.Drawing.Size(24, 20);
            this.btnSearchSupplier.TabIndex = 2;
            this.btnSearchSupplier.Text = "button1";
            this.btnSearchSupplier.UseVisualStyleBackColor = true;
            this.btnSearchSupplier.Click += new System.EventHandler(this.btnSearchSupplier_Click);
            // 
            // frmPurchasePayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 510);
            this.Controls.Add(this.panelPayment);
            this.Controls.Add(this.lblRemainingPayment);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgvPurchases);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grpSupplier);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPurchasePayment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase Payment";
            this.Load += new System.EventHandler(this.frmPurchasePayment_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grpSupplier.ResumeLayout(false);
            this.grpSupplier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPurchases)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panelPayment.ResumeLayout(false);
            this.panelPayment.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpSupplier;
        private System.Windows.Forms.Button btnAddSupplier;
        private System.Windows.Forms.Button btnSearchSupplier;
        private System.Windows.Forms.TextBox txtSearch;
        public System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvPurchases;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblRemainingPayment;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem;
        private System.Windows.Forms.Panel panelPayment;
        private System.Windows.Forms.Button btnPanelClose;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.TextBox txtRemainingPayment;
        private System.Windows.Forms.TextBox txtEnterPayment;
        private System.Windows.Forms.TextBox txtTotalPayment;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
    }
}