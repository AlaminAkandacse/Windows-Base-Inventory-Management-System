﻿using MBAManagementSystem.Forms.SaleForms;
using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.CustomerForms
{
    public partial class frmSearchCustomer : Form
    {
        frmSaleForms SaleForm;
        private frmSalePayment SalePaymentForm;
        public frmSearchCustomer(frmSalePayment frmsalePayment, string searchvalue)
        {
            InitializeComponent();
            this.SalePaymentForm = frmsalePayment;
            CustomerCls.GetCustomer(searchvalue,dgvCustomer);
        }

        public frmSearchCustomer(frmSaleForms saleforms, string searchvalue)
        {

            InitializeComponent();
            this.SaleForm = saleforms;
            CustomerCls.GetCustomer(searchvalue, dgvCustomer);
        }

        private void frmSearchCustomer_Load(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            CustomerCls.GetCustomer(txtSearch.Text.Trim(), dgvCustomer);
        }

        private void btnGetAll_Click(object sender, EventArgs e)
        {
            CustomerCls.GetCustomer("",dgvCustomer);
        }

        private void selectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvCustomer != null)
            {
                if (dgvCustomer.Rows.Count > 0)
                {
                    if (dgvCustomer.SelectedRows.Count == 1)
                    {
                        if (SaleForm != null)
                        {
                            SaleForm.selectCustomerid = Convert.ToString(dgvCustomer.CurrentRow.Cells[0].Value);
                            SaleForm.lblCustomer.Text = Convert.ToString(dgvCustomer.CurrentRow.Cells[1].Value) + "    Contact No : " + Convert.ToString(dgvCustomer.CurrentRow.Cells[2].Value);
                            this.Close();
                        }
                        else if (SalePaymentForm !=null) 
                        {
                            SalePaymentForm.customerid = Convert.ToString(dgvCustomer.CurrentRow.Cells[0].Value);
                            SalePaymentForm.lblCustomer.Text = Convert.ToString(dgvCustomer.CurrentRow.Cells[1].Value) + "    Contact No : " + Convert.ToString(dgvCustomer.CurrentRow.Cells[2].Value);
                            this.Close();

                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }
    }
}
