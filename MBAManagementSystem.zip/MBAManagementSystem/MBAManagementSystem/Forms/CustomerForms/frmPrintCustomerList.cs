﻿using MBAManagementSystem.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.CustomerForms
{
    public partial class frmPrintCustomerList : Form
    {
        public frmPrintCustomerList()
        {
            InitializeComponent();
        }

        private void frmPrintCustomerList_Load(object sender, EventArgs e)
        {
            rpt_CustomerListReport rpt = new rpt_CustomerListReport();
            rpt.Refresh();
            crv.ReportSource = rpt;
        }
    }
}
