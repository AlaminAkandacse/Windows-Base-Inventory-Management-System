﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.CustomerForms
{
    public partial class frmCustomer : Form
    {
        public frmCustomer()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select CustomerID [ID], CustomerName [Customer], ContactNo [Contact No], Area [Customer Area], Address, Description from CustomerTable";
            }
            else
            {
                query = "select CustomerID [ID], CustomerName [Customer], ContactNo [Contact No], Area [Customer Area], Address,Description from CustomerTable where (CustomerName+''+ContactNo+''+Area+''+Address+''+Description) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvCustomerList.DataSource = dt;
                    dgvCustomerList.Columns[0].Width = 100;
                    dgvCustomerList.Columns[1].Width = 100;
                    dgvCustomerList.Columns[2].Width = 100;
                    dgvCustomerList.Columns[3].Width = 100;
                    dgvCustomerList.Columns[4].Width = 200;
                    dgvCustomerList.Columns[5].Width = 200;
                }
                else
                {
                    dgvCustomerList.DataSource = null;
                }
            }
            else
            {
                dgvCustomerList.DataSource = null;
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            FormClear();
        }
        private void FormClear()
        {
            txtCustomerName.Clear();
            txtContactNo.Clear();
            txtCustomerArea.Clear();
            txtAddress.Clear();
            txtDescription.Clear();

        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvCustomerList.Enabled = false;
            txtSearch.Enabled = false;

        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvCustomerList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            FormClear();
        }
        private void frmCustomer_Load(object sender, EventArgs e)
        {
            FillGrid("");
           
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtCustomerName.Text.Trim().Length == 0)
            {
                ep.SetError(txtCustomerName, "Please Enter Customer Name!");
                txtCustomerName.Focus();
                return;
            }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please Enter Contact No!");
                txtContactNo.Focus();
                return;
            }

            if (txtAddress.Text.Trim().Length == 0)
            {
                ep.SetError(txtAddress, "Please Enter Address!");
                txtAddress.Focus();
                return;
            }

            if (txtCustomerArea.Text.Trim().Length == 0)
            {
                ep.SetError(txtCustomerArea, "Please Enter Customer Area!");
                txtCustomerArea.Focus();
                return;
            }

            if (txtDescription.Text.Trim().Length == 0)
            {
                ep.SetError(txtDescription, "Please Enter Description!");
                txtDescription.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from CustomerTable where ContactNo='" + txtContactNo.Text.Trim() + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtContactNo, "Already Exist!");
                    txtContactNo.Focus();
                    return;
                }
            }


            string query = string.Format("insert into CustomerTable(CustomerName,ContactNo,Area,Address,Description) values('{0}','{1}','{2}','{3}','{4}')", txtCustomerName.Text.Trim(), txtContactNo.Text.Trim(), txtCustomerArea.Text.Trim(), txtAddress.Text.Trim(), txtDescription.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                FillGrid("");
                FormClear();
            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvCustomerList != null)
            {
                if (dgvCustomerList.Rows.Count > 0)
                {
                    if (dgvCustomerList.SelectedRows.Count == 1)
                    {
                        txtCustomerName.Text = Convert.ToString(dgvCustomerList.CurrentRow.Cells[1].Value);
                        txtContactNo.Text = Convert.ToString(dgvCustomerList.CurrentRow.Cells[2].Value);
                        txtCustomerArea.Text = Convert.ToString(dgvCustomerList.CurrentRow.Cells[3].Value);
                        txtAddress.Text = Convert.ToString(dgvCustomerList.CurrentRow.Cells[4].Value);
                        txtDescription.Text = Convert.ToString(dgvCustomerList.CurrentRow.Cells[5].Value);

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty");
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtCustomerName.Text.Trim().Length == 0)
            {
                ep.SetError(txtCustomerName, "Please Enter Customer Name!");
                txtCustomerName.Focus();
                return;
            }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please Enter Contact No!");
                txtContactNo.Focus();
                return;
            }

            if (txtAddress.Text.Trim().Length == 0)
            {
                ep.SetError(txtAddress, "Please Enter Address!");
                txtAddress.Focus();
                return;
            }

            if (txtCustomerArea.Text.Trim().Length == 0)
            {
                ep.SetError(txtCustomerArea, "Please Enter Customer Area!");
                txtCustomerArea.Focus();
                return;
            }

            if (txtDescription.Text.Trim().Length == 0)
            {
                ep.SetError(txtDescription, "Please Enter Description!");
                txtDescription.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from CustomerTable where ContactNo='" + txtContactNo.Text.Trim() + "' and CustomerID !='" + dgvCustomerList.CurrentRow.Cells[0].Value + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtContactNo, "Already Exist!");
                    txtContactNo.Focus();
                    return;
                }
            }


            string updatequery = string.Format("update  CustomerTable set CustomerName='{0}', ContactNo='{1}', Area='{2}', Address='{3}', Description='{4}' where CustomerID='{5}'", txtCustomerName.Text.Trim(), txtContactNo.Text.Trim(), txtCustomerArea.Text.Trim(), txtAddress.Text.Trim(), txtDescription.Text.Trim(), dgvCustomerList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(updatequery);
            if (result)
            {
                MessageBox.Show("Update Successfully");
                FillGrid("");
                DesibleControls();

            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            frmPrintCustomerList frm = new frmPrintCustomerList();
            frm.Show();

        }

      
    }
}
