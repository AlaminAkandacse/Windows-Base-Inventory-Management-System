﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.StockForms
{
    public partial class frmCategories : Form
    {
        public frmCategories()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select CategoryID [ID], CategoryName [Category], isDeleted from CategoryTable where IsDeleted=0";
            }
            else
            {
                query = "select CategoryID [ID], CategoryName [Category], isDeleted from CategoryTable where CategoryName like '%" + searchvalue + "%' and IsDeleted=0";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvCategoryList.DataSource = dt;
                    dgvCategoryList.Columns[0].Width = 100;
                    dgvCategoryList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dgvCategoryList.Columns[2].Visible = false; ;
                }
                else
                {
                    dgvCategoryList.DataSource = null;
                }
            }
            else
            {
                dgvCategoryList.DataSource = null;
            }
            chkisDeleted.Checked = false;
        }


        private void FillGridISDeleted(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select CategoryID [ID], CategoryName [Category], isDeleted from CategoryTable where IsDeleted=1";
            }
            else
            {
                query = "select CategoryID [ID], CategoryName [Category], isDeleted from CategoryTable where CategoryName like '%" + searchvalue + "%' and IsDeleted=1";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvCategoryList.DataSource = dt;
                    dgvCategoryList.Columns[0].Width = 100;
                    dgvCategoryList.Columns[1].Width = 100;
                    dgvCategoryList.Columns[2].Width = 100;
                }
                else
                {
                    dgvCategoryList.DataSource = null;
                }
            }
            else
            {
                dgvCategoryList.DataSource = null;
            }
        }

        private void frmCategories_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCategory.Clear();
        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvCategoryList.Enabled = false;
            txtSearch.Enabled = false;
            chkisDeleted.Enabled = false;
        }

        private void DesibleControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvCategoryList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtCategory.Clear();
            chkisDeleted.Enabled = true;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DesibleControls();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtCategory.Text.Trim().Length == 0)
            {
                ep.SetError(txtCategory, "Please Enter Category Name!");
                txtCategory.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from CategoryTable where CategoryName='" + txtCategory.Text.Trim() + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtCategory, "Already Exist!");
                    txtCategory.Focus();
                    return;
                }
            }


            string query = string.Format("insert into CategoryTable(CategoryName) values('{0}')", txtCategory.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Save Successfully");
                chkisDeleted.Checked = false;
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtCategory.Text.Trim().Length == 0)
            {
                ep.SetError(txtCategory, "Please Enter Category Name!");
                txtCategory.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrive("select * from CategoryTable where CategoryName='" + txtCategory.Text.Trim() + "' and CategoryID !='" + Convert.ToString(dgvCategoryList.CurrentRow.Cells[0].Value) + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtCategory, "Already Exist!");
                    txtCategory.Focus();
                    return;
                }
            }

            string query = string.Format("update  CategoryTable set CategoryName='{0}' where CategoryID = '{1}'", txtCategory.Text.Trim(), Convert.ToString(dgvCategoryList.CurrentRow.Cells[0].Value));
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated Successfully");
                FillGrid("");
                DesibleControls();
            }
            else
            {
                MessageBox.Show("Unexpected is Occure! Please Contact to Concern person.");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvCategoryList != null)
            {
                if (dgvCategoryList.Rows.Count > 0)
                {
                    if (dgvCategoryList.SelectedRows.Count == 1)
                    {
                        txtCategory.Text = Convert.ToString(dgvCategoryList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty");
                }


            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvCategoryList != null)
            {
                if (dgvCategoryList.Rows.Count > 0)
                {
                    if (dgvCategoryList.SelectedRows.Count == 1)
                    {

                        if (deleteToolStripMenuItem.Text == "Delete")
                        {

                            if (MessageBox.Show("Are you Sure you want to delete Selected Record!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {

                                string deletequery = "update CategoryTable set IsDeleted=1 where CategoryID='" + dgvCategoryList.CurrentRow.Cells[0].Value + "'";

                                bool result = DatabaseAccess.Delete(deletequery);
                                if (result)
                                {
                                    MessageBox.Show("Deleted Successfully");
                                    FillGrid("");
                                    

                                }
                            }
                        }
                        else if (deleteToolStripMenuItem.Text=="Recover") 
                        {
                            if (MessageBox.Show("Are you Sure you want to recover Selected Record!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {

                                string deletequery = "update CategoryTable set IsDeleted=0 where CategoryID='" + dgvCategoryList.CurrentRow.Cells[0].Value + "'";

                                bool result = DatabaseAccess.Delete(deletequery);
                                if (result)
                                {
                                    MessageBox.Show("Recover Successfully");
                                    FillGrid("");

                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is Empty");
                }


            }
        }

        private void chkisDeleted_CheckedChanged(object sender, EventArgs e)
        {
            if (chkisDeleted.Checked == true)
            {
                FillGridISDeleted("");
            }
            else 
            {
                FillGrid("");
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (chkisDeleted.Checked == true)
            {
                FillGridISDeleted(txtSearch.Text.Trim());
            }
            else
            {
                FillGrid(txtSearch.Text.Trim());
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (dgvCategoryList != null)
            {
                if (dgvCategoryList.Rows.Count > 0)
                {
                    if (dgvCategoryList.SelectedRows.Count == 1)
                    {
                        if (Convert.ToBoolean(dgvCategoryList.CurrentRow.Cells[2].Value) == true)
                        {
                            deleteToolStripMenuItem.Text = "Recover";
                        }
                        else 
                        {
                            deleteToolStripMenuItem.Text = "Delete";
                        }
                    }
                }
                else 
                {
                deleteToolStripMenuItem.Text = "Delete";

                }

            }
            else 
            {
                deleteToolStripMenuItem.Text = "Delete";
            }
        }
    }
}
