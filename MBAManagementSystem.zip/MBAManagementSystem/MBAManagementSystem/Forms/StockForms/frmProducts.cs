﻿using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.StockForms
{
    public partial class frmProducts : Form
    {
        public frmProducts()
        {
            InitializeComponent();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            ComboHelper.FillCategories(cmbSelectCategory);
            FillGrid("");
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            frmCategories frm = new frmCategories();
            frm.ShowDialog();
            ComboHelper.FillCategories(cmbSelectCategory);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillCategories(cmbSelectCategory);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();

            if (cmbSelectCategory.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectCategory, "Please Select Category");
                cmbSelectCategory.Focus();
                return;
            }

            if (txtProductName.Text.Trim().Length == 0) 
            {
                ep.SetError(txtProductName,"Please Enter Product Name");
                txtProductName.Focus();
                return;
            }
            string checkquery = string.Format("select * from StockTable where CategoryID='{0}' and ProductName='{1}'",cmbSelectCategory.SelectedValue,txtProductName.Text.Trim());
            DataTable dt = DatabaseAccess.Retrive(checkquery);
            if (dt !=null) 
            {
                if (dt.Rows.Count>0)
                {
                    ep.SetError(txtProductName, "Already Exist");
                    txtProductName.Focus();
                    return;
                }
            }

            string insertquery = string.Format("insert into StockTable(CategoryID,UserID,ProductName,ExpiryDate,MfturDate,Description) values('{0}','{1}','{2}','{3}','{4}','{5}')",cmbSelectCategory.SelectedValue,CurrentUser.UserID,txtProductName.Text.Trim(),dtpExpiryDate.Value.ToString("dd/MM/yyyy"),dtpManufactureDate.Value.ToString("dd/MM/yyyy"),txtDescription.Text.Trim());
            bool result = DatabaseAccess.Insert(insertquery);
            if (result) 
            {
                MessageBox.Show("Product Add Successfully");
                FormClear();
                FillGrid("");
            }

        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select * from v_ProductList";
            }
            else
            {
                query = "select * from v_ProductList where (Category+''+Product+''+User+''+Description) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvProductList.DataSource = dt;
                    dgvProductList.Columns[0].Width = 100;
                    dgvProductList.Columns[1].Visible = false;
                    dgvProductList.Columns[2].Width = 120;
                    dgvProductList.Columns[3].Visible = false;
                    dgvProductList.Columns[4].Width = 150;
                    dgvProductList.Columns[5].Width = 150;
                    dgvProductList.Columns[6].Width = 150;
                    dgvProductList.Columns[7].Width = 150;
                    dgvProductList.Columns[8].Width = 150;
                    dgvProductList.Columns[9].Width = 150;
                    dgvProductList.Columns[10].Width = 150;
                    dgvProductList.Columns[11].Width = 150;
                    dgvProductList.Columns[12].Width = 100;
                    dgvProductList.Columns[13].Width = 300;
                    //dgvProductList.Columns[0].Width = 100;
                    //dgvProductList.Columns[1].Width = 100;
                    //dgvProductList.Columns[2].Width = 100;
                }
                else
                {
                    dgvProductList.DataSource = null;
                }
            }
            else
            {
                dgvProductList.DataSource = null;
            }
        }

        private void FormClear()
        {
            txtProductName.Clear();
            cmbSelectCategory.SelectedIndex = 0;
            txtDescription.Clear();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

      
    }
}
