﻿using MBAManagementSystem.Forms.CustomerForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.SaleForms
{
    public partial class frmSalePayment : Form
    {

        public string customerid = string.Empty;
        public frmSalePayment()
        {
            InitializeComponent();
        }

        private void frmSalePayment_Load(object sender, EventArgs e)
        {

        }

        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            frmSearchCustomer frm = new frmSearchCustomer(this, txtSearch.Text.Trim());
            frm.ShowDialog();
            GetAllUnPaidSalesInvoice();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            frmCustomer frm = new frmCustomer();
            frm.ShowDialog();
        }


        private void GetAllUnPaidSalesInvoice()
        {
            try
            {
                if (string.IsNullOrEmpty(customerid))
                {
                    dgvSales.DataSource = null;
                    return;
                }

                string query = "SELECT VAS.CustomerInvoiceID [ID],VAS.CustomerID [CustomerID],VAS.CustomerName [Customer],VAS.InvoiceNo [Invoice No], " +
                               "  VAS.InvoiceDate[Date],VAS.Title[Title],VAS.TotalAmount[Total Amount],(VAS.TotalAmount - ISNULL(CPT.Payment, 0)) as [Remaining Amount] " +
                               "  ,VAS.UserName[User],Description FROM v_AllSales VAS LEFT JOIN(select CustomerInvoiceID, sum(PaidAmount) " +
                               " as [Payment] from CustomerPaymentTable group by CustomerInvoiceID) CPT ON VAS.CustomerInvoiceID = CPT.CustomerInvoiceID " +
                               " where VAS.TotalAmount > isnull(CPT.Payment, 0) AND VAS.CustomerID = '"+customerid+"'";

                DataTable dt = DatabaseAccess.Retrive(query);
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        dgvSales.DataSource = dt;
                        dgvSales.Columns[0].Visible = false;//ID
                        dgvSales.Columns[1].Visible = false;//Customer ID
                        dgvSales.Columns[2].Visible = false;//CustomerName
                        dgvSales.Columns[3].Width = 150;//InvoiceNo
                        dgvSales.Columns[4].Width = 120;//InvoiceDate
                        dgvSales.Columns[5].Visible = false;//Title
                        dgvSales.Columns[6].Width = 120;//TotalAmount
                        dgvSales.Columns[7].Width = 120;//Remaining Amount
                        dgvSales.Columns[8].Width = 80;//UserName
                        dgvSales.Columns[9].Width = 230;//Description
                        CalculateReaminingPayment();
                        return;
                    }
                }
                dgvSales.DataSource = null;
                CalculateReaminingPayment();

            }
            catch (Exception)
            {
                dgvSales.DataSource = null;
                MessageBox.Show("Unexpectted Error id Occur Please Contact to Concern Person!");
            }


        }


        private void CalculateReaminingPayment()
        {
            float totalpayment = 0;
            if (dgvSales != null)
            {
                if (dgvSales.Rows.Count > 0)
                {
                    foreach (DataGridViewRow item in dgvSales.Rows)
                    {
                        float payment = 0;
                        float.TryParse(Convert.ToString(item.Cells[7].Value), out payment);
                        totalpayment = totalpayment + payment;
                    }

                }
            }
            lblRemainingPayment.Text = Convert.ToString(totalpayment);
        }

        private void btnPanelClose_Click(object sender, EventArgs e)
        {
            panelPayment.Visible = false;
            dgvSales.Enabled = true;
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSales != null)
            {
                if (dgvSales.Rows.Count > 0)
                {
                    if (dgvSales.SelectedRows.Count == 1)
                    {
                        dgvSales.Enabled = false;
                        float payment = 0;
                        panelPayment.Visible = true;

                        foreach (DataGridViewRow item in dgvSales.Rows)
                        {
                            if (item.Selected == true)
                            {
                                float.TryParse(Convert.ToString(item.Cells[7].Value), out payment);

                            }
                        }

                        txtSaleAmount.Text = Convert.ToString(payment);
                    }
                    else if (dgvSales.SelectedRows.Count > 1)
                    {
                        dgvSales.Enabled = true;
                        panelPayment.Visible = false;

                        //multiple Payment
                        SalesPayments();

                    }

                }
            }
        }

        private void txtPaidAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtPaidAmount_TextChanged(object sender, EventArgs e)
        {
            float paidamount = 0;
            float totalsaleamount = 0;
            float.TryParse(txtSaleAmount.Text.Trim(), out totalsaleamount);
            float.TryParse(txtPaidAmount.Text.Trim(), out paidamount);
            txtRemainingAmount.Text = (totalsaleamount - paidamount).ToString();
        }

        private void btnPaid_Click(object sender, EventArgs e)
        {

            if (dgvSales.SelectedRows.Count != 1)
            {
                MessageBox.Show("Please Select one Invoice!");
                return;
            }
            float totalsaleamount = 0;
            float totalpaidamount = 0;
            float totalremainingamount = 0;
            foreach (DataGridViewRow item in dgvSales.Rows)
            {
                if (item.Selected == true)
                {
                    float.TryParse(Convert.ToString(item.Cells[6].Value), out totalsaleamount);

                }
            }

            float.TryParse(txtPaidAmount.Text.Trim(), out totalpaidamount);
            float.TryParse(txtRemainingAmount.Text.Trim(), out totalremainingamount);

            string FinancialYearID = (DatabaseAccess.Retrive("select top 1 FinancialYearID from FinancialYearTable where IsActive=1") != null ? Convert.ToString(DatabaseAccess.Retrive("select top 1 financialYearID from FinancialYearTable where IsActive=1").Rows[0][0]) : string.Empty);

            string paidinvoiceno = "PIV" + DateTime.Now.ToString("ddMMyyyyHHmmssmm");
            string transactiontitle = "Invoice Paid is" + lblCustomer.Text.Trim();
            string creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
            FinancialYearID, "1", "2", "0", paidinvoiceno, CurrentUser.UserID, totalpaidamount, "0", DateTime.Now, transactiontitle);

            transactiontitle = lblCustomer.Text.Trim() + ", Sale Payment is Succesed";
            string debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
            FinancialYearID, "1", "1", "0", paidinvoiceno, CurrentUser.UserID, "0", totalpaidamount, DateTime.Now, transactiontitle);

            DatabaseAccess.Insert(creditquery);
            DatabaseAccess.Insert(debittquery);

            string invoiceno = string.Empty;
            foreach (DataGridViewRow item in dgvSales.Rows)
            {
                if (item.Selected == true)
                {
                    invoiceno = Convert.ToString(item.Cells[0].Value);

                }
            }
            string paidquery = string.Format("insert into CustomerPaymentTable(CustomerID,CustomerInvoiceID,UserID,InvoiceNo,TotalAmount,PaidAmount,RemainingBalance) " +
                     " values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}')",
                      customerid, invoiceno, CurrentUser.UserID, paidinvoiceno, totalsaleamount, totalpaidamount, totalremainingamount);
            DatabaseAccess.Insert(paidquery);

            MessageBox.Show("Paid Successfull");
            dgvSales.Enabled = true;
            panelPayment.Visible = false;
            GetAllUnPaidSalesInvoice();
        }


        private void SalesPayments()
        {


            if (dgvSales.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please Select  Invoice!");
                return;
            }

            string FinancialYearID = (DatabaseAccess.Retrive("select top 1 FinancialYearID from FinancialYearTable where IsActive=1") != null ? Convert.ToString(DatabaseAccess.Retrive("select top 1 financialYearID from FinancialYearTable where IsActive=1").Rows[0][0]) : string.Empty);


            foreach (DataGridViewRow item in dgvSales.Rows)
            {

                float totalsaleamount = 0;
                float totalpaidamount = 0;

                string invoiceno = string.Empty;
                //float totalremainingamount = 0;

                if (item.Selected == true)
                {
                    float.TryParse(Convert.ToString(item.Cells[6].Value), out totalsaleamount);
                    float.TryParse(Convert.ToString(item.Cells[7].Value), out totalpaidamount);
                    invoiceno = Convert.ToString(item.Cells[0].Value);
                }

               string paidinvoiceno = "PIV" + DateTime.Now.ToString("ddMMyyyyHHmmssmm");

                string transactiontitle = "Invoice Paid is" + lblCustomer.Text.Trim();
                string creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                FinancialYearID, "1", "2", "0", paidinvoiceno, CurrentUser.UserID, totalpaidamount, "0", DateTime.Now, transactiontitle);

                transactiontitle = lblCustomer.Text.Trim() + ", Sale Payment is Succesed";
                string debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                FinancialYearID, "1", "1", "0", paidinvoiceno, CurrentUser.UserID, "0", totalpaidamount, DateTime.Now, transactiontitle);

                DatabaseAccess.Insert(creditquery);
                DatabaseAccess.Insert(debittquery);

                string paidquery = string.Format("insert into CustomerPaymentTable(CustomerID,CustomerInvoiceID,UserID,InvoiceNo,TotalAmount,PaidAmount,RemainingBalance) " +
                        " values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}')",
                         customerid, invoiceno, CurrentUser.UserID, paidinvoiceno, totalsaleamount, totalpaidamount, "0");
                DatabaseAccess.Insert(paidquery);
                Thread.Sleep(1000);
            }
            MessageBox.Show("All Invoice Paid Successfully");
            dgvSales.Enabled = true;
            panelPayment.Visible = false;
            GetAllUnPaidSalesInvoice();

        }

    }
}
