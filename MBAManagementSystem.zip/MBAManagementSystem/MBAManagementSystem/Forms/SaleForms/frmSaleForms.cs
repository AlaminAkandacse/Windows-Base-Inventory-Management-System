﻿using MBAManagementSystem.Forms.AccountForms;
using MBAManagementSystem.Forms.CustomerForms;
using MBAManagementSystem.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.Forms.SaleForms
{
    public partial class frmSaleForms : Form
    {
        public string selectCustomerid = string.Empty;

        private DataTable dtEntries = null;
        public frmSaleForms()
        {
            InitializeComponent();
        }

        private void SetPurchaseCartColumnsWidth()
        {

            dgvSaleCart.Columns[1].Width = 100;
            dgvSaleCart.Columns[3].Width = 150;
            dgvSaleCart.Columns[4].Width = 180;
            dgvSaleCart.Columns[5].Width = 120;
            dgvSaleCart.Columns[6].Width = 180;
            dgvSaleCart.Columns[7].Width = 150;
        }

        private void frmSaleForms_Load(object sender, EventArgs e)
        {
            ComboHelper.FillCategories(cmbCategory);
            ComboHelper.FillAccountHeadControls(cmbAccount);
            SetPurchaseCartColumnsWidth();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            frmCustomer frm = new frmCustomer();
            frm.ShowDialog();
        }

        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            frmSearchCustomer frm = new frmSearchCustomer(this,txtSearch.Text.Trim());
            frm.ShowDialog();
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboHelper.FillProductByCategory(cmbProduct, cmbCategory.SelectedValue.ToString());
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillCategories(cmbCategory);
        }

        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbProduct.SelectedIndex > 0)
                {

                    DataTable dt = DatabaseAccess.Retrive("select top 1 Quantity,SaleUnitPrice from StockTable where ProductID='" + Convert.ToString(cmbProduct.SelectedValue) + "'");

                    txtSaleQty.Text = "0";
                    if (dt != null)
                    {
                        lblAvaiableQuantity.Text = dt.Rows[0][0] == DBNull.Value ? "0" : Convert.ToString(dt.Rows[0][0]);
                        txtSaleUnitPrice.Text = dt.Rows[0][1] == DBNull.Value ? "0" : Convert.ToString(dt.Rows[0][1]);
                        lblSaleUnitPrice.Text = dt.Rows[0][1] == DBNull.Value ? "0" : Convert.ToString(dt.Rows[0][1]);
                        return;
                    }
                    else
                    {
                        txtSaleQty.Text = "0";
                        txtSaleUnitPrice.Text = "0";
                      
                    }
                }
                else
                {
               
                    txtSaleUnitPrice.Text = "0";
                    txtSaleQty.Text = "0";
                }
            }
            catch
            {

                txtSaleUnitPrice.Text = "0";
                txtSaleQty.Text = "0";

            }
        }

        private void GetItemCost() 
        {
            float quantity = 0;
            float saleunitprice = 0;
            float.TryParse(txtSaleUnitPrice.Text.Trim(), out saleunitprice);
            float.TryParse(txtSaleQty.Text.Trim(), out quantity);
            txtItemCost.Text = Convert.ToString(quantity*saleunitprice);
        }


        private void EnableUpdateComponent()
        {
            dgvSaleCart.Enabled = false;
            btnAdd.Enabled = false;
            btnClear.Enabled = false;
            btnUpdate.Enabled = true;
            btnCancel.Enabled = true;
            btnNewSale.Enabled = false;
            btnFinalize.Enabled = false;
            chkSetPayment.Enabled = false;
            grpCustomer.Enabled = false;
        }

        private void ResetControls()
        {
            dgvSaleCart.Enabled = true;
            btnAdd.Enabled = true;
            btnClear.Enabled = true;
            btnUpdate.Enabled = false;
            btnCancel.Enabled = false;
            btnNewSale.Enabled = true;
            btnFinalize.Enabled = true;
            chkSetPayment.Enabled = true;
            grpCustomer.Enabled = true;
            ClearForm();
        }
        private void ClearForm()
        {
            cmbProduct.SelectedIndex = 0;
            txtSaleQty.Text = "0";
            lblReamainingPayment.Text = "0";
            lblAlreadyPaid.Text = "0";
            chkSetPayment.Checked = false;
        }

        private void txtSaleQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtSaleUnitPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {

            }
        }

        private void txtSaleQty_TextChanged(object sender, EventArgs e)
        {
            GetItemCost();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ResetControls();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbCategory.SelectedIndex == 0)
            {
                ep.SetError(cmbCategory, "Please Select Category");
                cmbCategory.Focus();
                return;
            }
            if (cmbProduct.SelectedIndex == 0)
            {
                ep.SetError(cmbProduct, "Please Select Product");
                cmbProduct.Focus();
                return;
            }
            if (cmbAccount.SelectedIndex == 0)
            {
                ep.SetError(cmbAccount, "Please Select Account, Like New Sale!");
                cmbAccount.Focus();
                return;
            }

            if (txtSaleQty.Text.Trim().Length == 0)
            {
                ep.SetError(txtSaleQty, "Please Enter Sale Qty");
                txtSaleQty.Focus();
                return;
            }

            if (txtSaleUnitPrice.Text.Trim().Length == 0)
            {
                ep.SetError(txtSaleUnitPrice, "Please Enter Sale Unit Price");
                txtSaleUnitPrice.Focus();
                return;
            }




            int saleqty = 0;
            float saleunitprice;
            int avaiablestockqty = 0;
            int.TryParse(lblAvaiableQuantity.Text.Trim(), out avaiablestockqty);
            int.TryParse(txtSaleQty.Text.Trim(), out saleqty);
            float.TryParse(txtSaleUnitPrice.Text.Trim(), out saleunitprice);

            if (saleqty == 0)
            {
                ep.SetError(txtSaleQty, "Please Enter Sale Quantity");
                txtSaleQty.Focus();
                return;

            }


            if (saleunitprice == 0)
            {
                ep.SetError(txtSaleUnitPrice, "Please Enter Sale Unit Price");
                txtSaleUnitPrice.Focus();
                return;

            }

            if (saleqty > avaiablestockqty )
            {
                ep.SetError(txtSaleQty, "Sale Quantity must be equal or less than available quantity");
                txtSaleQty.Focus();
                txtSaleQty.SelectAll();
                return;
            }


            if (dgvSaleCart != null)
            {
                if (dgvSaleCart.Rows.Count > 0)
                {
                    foreach (DataGridViewRow checkrow in dgvSaleCart.Rows)
                    {
                        if (Convert.ToString(checkrow.Cells[0].Value) == Convert.ToString(cmbCategory.SelectedValue) && 
                            Convert.ToString(checkrow.Cells[0].Value) == Convert.ToString(cmbProduct.SelectedValue))
                        {
                            ep.SetError(cmbProduct, "Already Exist in Sale Cart");
                            cmbProduct.Focus();
                            checkrow.Selected = true;
                            return;

                        }
                    }
                }
            }
            DataGridViewRow createrow = new DataGridViewRow();
            createrow.CreateCells(dgvSaleCart);
            createrow.Cells[0].Value = cmbCategory.SelectedValue;
            createrow.Cells[1].Value = cmbCategory.Text;
            createrow.Cells[2].Value = cmbProduct.SelectedValue;
            createrow.Cells[3].Value = cmbProduct.Text;
            createrow.Cells[4].Value = cmbAccount.Text;
            createrow.Cells[5].Value = txtSaleQty.Text.Trim();
            createrow.Cells[6].Value = txtSaleUnitPrice.Text.Trim();
            createrow.Cells[7].Value = Convert.ToString(saleqty * saleunitprice);

            dgvSaleCart.Rows.Add(createrow);
            ClearForm();
            CalculateTotalAmount();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSaleCart != null)
            {
                if (dgvSaleCart.Rows.Count > 0)
                {
                    if (dgvSaleCart.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you Sure you want to delete selected record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            dgvSaleCart.Rows.RemoveAt(dgvSaleCart.CurrentRow.Index);
                            CalculateTotalAmount();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("Purchase Cart is Empty");
                }
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSaleCart != null)
            {
                if (dgvSaleCart.Rows.Count > 0)
                {
                    if (dgvSaleCart.SelectedRows.Count == 1)
                    {
                        cmbCategory.SelectedValue = Convert.ToString(dgvSaleCart.CurrentRow.Cells[0].Value);
                        cmbProduct.SelectedValue = Convert.ToString(dgvSaleCart.CurrentRow.Cells[2].Value);
                        cmbAccount.Text = Convert.ToString(dgvSaleCart.CurrentRow.Cells[4].Value);
                        txtSaleQty.Text = Convert.ToString(dgvSaleCart.CurrentRow.Cells[5].Value);
                        txtSaleUnitPrice.Text = Convert.ToString(dgvSaleCart.CurrentRow.Cells[6].Value);
                        txtItemCost.Text = Convert.ToString(dgvSaleCart.CurrentRow.Cells[7].Value);

                        EnableUpdateComponent();
                    }
                    else
                    {
                        MessageBox.Show("Please Select One Record!");
                    }
                }
                else
                {
                    MessageBox.Show("Sale Cart is Empty");
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbCategory.SelectedIndex == 0)
            {
                ep.SetError(cmbCategory, "Please Select Category");
                cmbCategory.Focus();
                return;
            }
            if (cmbProduct.SelectedIndex == 0)
            {
                ep.SetError(cmbProduct, "Please Select Product");
                cmbProduct.Focus();
                return;
            }
            if (cmbAccount.SelectedIndex == 0)
            {
                ep.SetError(cmbAccount, "Please Select Account, Like New Sale!");
                cmbAccount.Focus();
                return;
            }

            if (txtSaleQty.Text.Trim().Length == 0)
            {
                ep.SetError(txtSaleQty, "Please Enter Sale Qty");
                txtSaleQty.Focus();
                return;
            }

            if (txtSaleUnitPrice.Text.Trim().Length == 0)
            {
                ep.SetError(txtSaleUnitPrice, "Please Enter Sale Unit Price");
                txtSaleUnitPrice.Focus();
                return;
            }




            int saleqty = 0;
            float saleunitprice;
            int avaiablestockqty = 0;
            int.TryParse(lblAvaiableQuantity.Text.Trim(), out avaiablestockqty);
            int.TryParse(txtSaleQty.Text.Trim(), out saleqty);
            float.TryParse(txtSaleUnitPrice.Text.Trim(), out saleunitprice);

            if (saleqty == 0)
            {
                ep.SetError(txtSaleQty, "Please Enter Sale Quantity");
                txtSaleQty.Focus();
                return;

            }


            if (saleunitprice == 0)
            {
                ep.SetError(txtSaleUnitPrice, "Please Enter Sale Unit Price");
                txtSaleUnitPrice.Focus();
                return;

            }

            if (saleqty > avaiablestockqty)
            {
                ep.SetError(txtSaleQty, "Sale Quantity must be equal or less than available quantity");
                txtSaleQty.Focus();
                txtSaleQty.SelectAll();
                return;
            }


            int customerrowindex = dgvSaleCart.CurrentRow.Index;



            if (dgvSaleCart != null)
            {
                if (dgvSaleCart.Rows.Count > 0)
                {
                    foreach (DataGridViewRow checkrow in dgvSaleCart.Rows)
                    {
                        if (Convert.ToString(checkrow.Cells[0].Value) == Convert.ToString(cmbCategory.SelectedValue) &&
                            Convert.ToString(checkrow.Cells[0].Value) == Convert.ToString(cmbProduct.SelectedValue) &&
                            checkrow.Index !=customerrowindex)
                        {
                            ep.SetError(cmbProduct, "Already Exist in Sale Cart");
                            cmbProduct.Focus();
                            checkrow.Selected = true;
                            return;

                        }
                    }
                }
            }

            dgvSaleCart.Rows[customerrowindex].Cells[0].Value = cmbCategory.SelectedValue;
            dgvSaleCart.Rows[customerrowindex].Cells[1].Value = cmbCategory.Text;
            dgvSaleCart.Rows[customerrowindex].Cells[2].Value = cmbProduct.SelectedValue;
            dgvSaleCart.Rows[customerrowindex].Cells[3].Value = cmbProduct.Text;
            dgvSaleCart.Rows[customerrowindex].Cells[4].Value = cmbAccount.Text;
            dgvSaleCart.Rows[customerrowindex].Cells[5].Value = txtSaleQty.Text.Trim();
            dgvSaleCart.Rows[customerrowindex].Cells[6].Value = txtSaleUnitPrice.Text.Trim();
            dgvSaleCart.Rows[customerrowindex].Cells[7].Value = Convert.ToString(saleqty * saleunitprice);
            ResetControls();
            CalculateTotalAmount();
        }

        private void CalculateTotalAmount()
        {
            float totalpurchaseamount = 0;
            float alreadyPaid = 0;
            float reamainingpayment = 0;
            if (dgvSaleCart != null)
            {
                if (dgvSaleCart.Rows.Count > 0)
                {
                    foreach (DataGridViewRow item in dgvSaleCart.Rows)
                    {
                        float itemcost = 0;
                        float.TryParse(Convert.ToString(item.Cells[7].Value).Trim(), out itemcost);
                        totalpurchaseamount = totalpurchaseamount + itemcost;
                        string AccountHeadID = string.Empty;
                        string AccountControlID = string.Empty;
                        string AccountSubControlID = string.Empty;
                        Accounts.GetAccountDetails(Convert.ToString(item.Cells[4].Value), out AccountHeadID, out AccountControlID, out AccountSubControlID);

                        //Assets  1        Increase (Debit) Decrease(Credit)
                        //Liabilities  2   Increase (Credit) Decrease(Debit) -
                        //Expenses  3      Increase (Debit) Decrease(Credit) -
                        //Capital  4        Increase (Credit) Decrease(Debit)
                        //Revenue  5        Increase (Credit) Decrease(Debit) +

                        if (AccountHeadID == "5")
                        {

                            reamainingpayment = reamainingpayment + itemcost;
                        }
                        else
                        {
                            alreadyPaid = alreadyPaid + itemcost;

                        }
                    }
                }
            }
            lblPayment.Text = Convert.ToString(totalpurchaseamount);
            lblReamainingPayment.Text = Convert.ToString(reamainingpayment);
            lblAlreadyPaid.Text = Convert.ToString(alreadyPaid);

        }

        private void btnNewSale_Click(object sender, EventArgs e)
        {
            ResetControls();
        }

        private void btnFinalize_Click(object sender, EventArgs e)
        {
            ep.Clear();
            dtEntries = null;
            int customerid = 0;
            int.TryParse(selectCustomerid, out customerid);

            if (customerid == 0)
            {
                ep.SetError(txtSearch, "Please First Select Customer");
                txtSearch.Focus();
                return;
            }

            if (dgvSaleCart == null || dgvSaleCart.Rows.Count == 0)
            {
                ep.SetError(dgvSaleCart, "Sale Cart is Empty");
                dgvSaleCart.Focus();
                return;
            }
            CalculateTotalAmount();
            string invoiceno = "INV" + DateTime.Now.ToString("ddMMyyHHmmss");
            string saletitle = "Sale : " + lblCustomer.Text.Trim();
            float totalsaleamount = 0;
            float.TryParse(lblReamainingPayment.Text.Trim(), out totalsaleamount);


            string FinancialYearID = (DatabaseAccess.Retrive("select top 1 FinancialYearID from FinancialYearTable where IsActive=1") != null ? Convert.ToString(DatabaseAccess.Retrive("select top 1 financialYearID from FinancialYearTable where IsActive=1").Rows[0][0]) : string.Empty);
            if (string.IsNullOrEmpty(FinancialYearID))
            {
                MessageBox.Show("Please First Set Financial Year");
                frmFinancialYear frm = new frmFinancialYear();
                frm.ShowDialog();
                return;

            }

            //Add Invoice Header Details
            string insertcustomerinvoice = string.Format("insert into CustomerInvoiceTable(CustomerID, UserID, InvoiceNo, Title, TotalAmount,InvoiceDate, Description) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')",
              customerid, CurrentUser.UserID, invoiceno, saletitle, totalsaleamount, DateTime.Now.ToString("dd/MM/yyyy"), "");

            bool result = DatabaseAccess.Insert(insertcustomerinvoice);
            if (result == false)
            {
                ep.SetError(btnFinalize, "Please Check Sale Info in Finalizing some issued");
                btnFinalize.Focus();
                return;
            }

            // Get Invoice Purchase ID
            string CustomerInvoiceID = Convert.ToString(DatabaseAccess.Retrive("select max(CustomerInvoiceID) from CustomerInvoiceTable").Rows[0][0]);
            if (string.IsNullOrEmpty(CustomerInvoiceID))
            {
                ep.SetError(btnFinalize, "Please Check Sale Info in Finalizing some issue");
                btnFinalize.Focus();
                return;
            }

            string successmessage = "Sale Success";

            foreach (DataGridViewRow productrow in dgvSaleCart.Rows)
            {

                // Add Invoice Product details by Products
                string invoicedetailquery = string.Format("insert into CustomerInvoiceDetailsTable(CustomerInvoiceID,ProductID,SaleQty,SaleUnitPrice)values('{0}','{1}','{2}','{3}')",
                    CustomerInvoiceID, productrow.Cells[2].Value, productrow.Cells[5].Value, productrow.Cells[6].Value);
                bool invoicedetailsresult = DatabaseAccess.Insert(invoicedetailquery);
                if (invoicedetailsresult == false)
                {
                    break;
                }

                string saleqty = Convert.ToString(productrow.Cells[5].Value);

                string AccountHeadID = string.Empty;
                string AccountControlID = string.Empty;
                string AccountSubControlID = string.Empty;
                Accounts.GetAccountDetails(Convert.ToString(productrow.Cells[4].Value), out AccountHeadID, out AccountControlID, out AccountSubControlID);
                //Assets  1        Increase (Debit) Decrease(Credit)
                //Liabilities  2   Increase (Credit) Decrease(Debit)
                //Expenses  3      Increase (Debit) Decrease(Credit)
                //Capital  4        Increase (Credit) Decrease(Debit)
                //Revenue  5        Increase (Credit) Decrease(Debit)

                //string creditquery = string.Empty;
                //string debittquery = string.Empty;

                string transactiontitle = string.Empty;

                if (AccountControlID == "6" || AccountControlID == "5") //Sale Products
                {
                    transactiontitle = "Sale on " + lblCustomer.Text.Trim();
                    //creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, invoiceno, CurrentUser.UserID.ToString(), Convert.ToString(productrow.Cells[7].Value), "0", DateTime.Now, transactiontitle);

                    transactiontitle = lblCustomer.Text.Trim() + ", Sale Payment is Pending";
                    //debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, "1", "2", "0", invoiceno, CurrentUser.UserID.ToString(), "0", Convert.ToString(productrow.Cells[7].Value), DateTime.Now, transactiontitle);

                    //DatabaseAccess.Insert(creditquery);
                    //DatabaseAccess.Insert(debittquery);

                }

                else if (AccountControlID == "2" || AccountControlID == "1") //Account Receivable
                {

                    transactiontitle = "Invoice is Paid from " + lblCustomer.Text.Trim();
                    //creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, invoiceno, CurrentUser.UserID.ToString(), Convert.ToString(productrow.Cells[7].Value), "0", DateTime.Now, transactiontitle);

                    transactiontitle = lblCustomer.Text.Trim() + ", Sale Payment is Succesed ";
                    //debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, "1", "1", "0", invoiceno, CurrentUser.UserID.ToString(), "0", Convert.ToString(productrow.Cells[7].Value), DateTime.Now, transactiontitle);

                    //DatabaseAccess.Insert(creditquery);
                    //DatabaseAccess.Insert(debittquery);

                }

                else if (AccountControlID == "3" || AccountControlID == "2") //Account Payable
                {

                    transactiontitle = "Sale Products in Previous Payments " + lblCustomer.Text.Trim();
                    //creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, "5", "6", "0", invoiceno, CurrentUser.UserID.ToString(), Convert.ToString(productrow.Cells[7].Value), "0", DateTime.Now, transactiontitle);

                    transactiontitle = lblCustomer.Text.Trim() + ", Sale Product in Previous Payments";
                    //debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, invoiceno, CurrentUser.UserID.ToString(), "0", Convert.ToString(productrow.Cells[7].Value), DateTime.Now, transactiontitle);

                    //DatabaseAccess.Insert(creditquery);
                    //DatabaseAccess.Insert(debittquery);

                }

                else if (AccountControlID == "25" || AccountControlID == "3") //Return Sale
                {

                    transactiontitle = "Return Sale From" + lblCustomer.Text.Trim();
                    //creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, "2", "3", "0", invoiceno, CurrentUser.UserID.ToString(), Convert.ToString(productrow.Cells[7].Value), "0", DateTime.Now, transactiontitle);

                    transactiontitle = lblCustomer.Text.Trim() + ", Return Sale Products";
                    //debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, invoiceno, CurrentUser.UserID.ToString(), "0", Convert.ToString(productrow.Cells[7].Value), DateTime.Now, transactiontitle);

                    //DatabaseAccess.Insert(creditquery);
                    //DatabaseAccess.Insert(debittquery);
                    saleqty = "(-" + saleqty+")";

                }
                else if (AccountControlID == "26" || AccountControlID == "4") //Sale on Capital
                {

                    transactiontitle = "Sale on Capital" + lblCustomer.Text.Trim();
                    //creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, "1", "2", "0", invoiceno, CurrentUser.UserID.ToString(), Convert.ToString(productrow.Cells[7].Value), "0", DateTime.Now, transactiontitle);

                    transactiontitle = lblCustomer.Text.Trim() + ", Sale on Owner";
                    //debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                    SetEntries(FinancialYearID, AccountHeadID, AccountControlID, AccountSubControlID, invoiceno, CurrentUser.UserID.ToString(), "0", Convert.ToString(productrow.Cells[7].Value), DateTime.Now, transactiontitle);

                    //DatabaseAccess.Insert(creditquery);
                    //DatabaseAccess.Insert(debittquery);

                }

                // Stock Update
                string updatestockquery = string.Format("update StockTable set Quantity= Quantity - '{0}' where ProductID='{1}'",
                    saleqty, Convert.ToString(productrow.Cells[2].Value).Trim());
                bool productupdateresult = DatabaseAccess.Update(updatestockquery);
                if (productupdateresult == false)
                {
                    Accounts.DeletePurchaseInvoiceDetails(CustomerInvoiceID);
                    Accounts.DeleteTransactionDetails(invoiceno);
                    break;
                }
            }


            if (dtEntries != null)
            {
                foreach (DataRow entryrow in dtEntries.Rows)
                {

                    string entryquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                     Convert.ToString(entryrow[0]), Convert.ToString(entryrow[1]), Convert.ToString(entryrow[2]), Convert.ToString(entryrow[3]), Convert.ToString(entryrow[4]), Convert.ToString(entryrow[5]), Convert.ToString(entryrow[6]), Convert.ToString(entryrow[7]), Convert.ToString(entryrow[8]), Convert.ToString(entryrow[9]));
                    DatabaseAccess.Insert(entryquery);

                }

            }


            if (chkSetPayment.Checked == true)
            {
               string paidinvoiceno = "PIV" + DateTime.Now.ToString("ddMMyyyyHHmmssmm");
               string transactiontitle = "Invoice Paid is" + lblCustomer.Text.Trim();
                string creditquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                FinancialYearID, "1", "2", "0", paidinvoiceno, CurrentUser.UserID, totalsaleamount, "0", DateTime.Now, transactiontitle);

                transactiontitle = lblCustomer.Text.Trim() + ", Sale Payment is Succesed";
                string debittquery = string.Format("insert into TransactionsTable(FinancialYearID,AccountHeadID,AccountControlID,AccountSubControlID,InvoiceNo,UserID,Credit,Debit,TransactionDate,TransactionTitle) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                FinancialYearID, "1", "1", "0", paidinvoiceno, CurrentUser.UserID, "0", totalsaleamount, DateTime.Now, transactiontitle);

                DatabaseAccess.Insert(creditquery);
                DatabaseAccess.Insert(debittquery);

                //DataTable totalamounttable = DatabaseAccess.Retrive(string.Format("select top 1 TotalAmount from CustomerPaymentTable where CustomerPaymentID = "
                //   + " (select max(CustomerPaymentID) from CustomerPaymentTable where CustomerID='{0}'", customerid));

                //float totalamount = 0;
                //if (totalamounttable != null)
                //{
                //    float.TryParse(Convert.ToString(totalamounttable.Rows[0][0]), out totalamount);
                //}
                string paymentquery = string.Format("insert into CustomerPaymentTable(CustomerID,CustomerInvoiceID,UserID,InvoiceNo,TotalAmount,PaidAmount,RemainingBalance) " +
               " values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}')",
                customerid, CustomerInvoiceID, CurrentUser.UserID, paidinvoiceno, totalsaleamount, totalsaleamount, "0");

                DatabaseAccess.Insert(paymentquery);


                successmessage = successmessage + "with Payment.";
            }
            MessageBox.Show(successmessage);
            this.Close();
        }


        private void SetEntries(string FinancialYearID,
            string AccountHeadID,
            string AccountControlID,
            string AccountSubControlID,
            string InvoiceNo,
            string UserID,
            string Credit,
            string Debit,
            DateTime TransactionDate,
            string TransactionTitle)
        {
            if (dtEntries == null)
            {
                dtEntries = new DataTable();
                dtEntries.Columns.Add("FinancialYearID");
                dtEntries.Columns.Add("AccountHeadID");
                dtEntries.Columns.Add("AccountControlID");
                dtEntries.Columns.Add("AccountSubControlID");
                dtEntries.Columns.Add("UserID");
                dtEntries.Columns.Add("Credit");
                dtEntries.Columns.Add("Debit");
                dtEntries.Columns.Add("TransactionDate");
                dtEntries.Columns.Add("TransactionTitle");
            }


            if (dtEntries != null)
            {
                if (dtEntries.Rows.Count > 0)
                {
                    dtEntries.Rows.Add(FinancialYearID,
                    AccountHeadID,
                    AccountControlID,
                    AccountSubControlID,
                    InvoiceNo,
                    UserID,
                    Credit,
                    Debit,
                    TransactionDate,
                    TransactionTitle);
                }
                else
                {
                    bool isupdated = false;
                    foreach (DataRow item in dtEntries.Rows)
                    {
                        decimal creditvalue = 0;
                        decimal debitvalue = 0;
                        decimal.TryParse(Convert.ToString(item[6]).Trim(), out creditvalue);
                        decimal.TryParse(Convert.ToString(item[7]).Trim(), out debitvalue);

                        if (Convert.ToString(item[1]).Trim() == AccountHeadID.Trim() &&
                            Convert.ToString(item[2]).Trim() == AccountControlID.Trim() &&
                            Convert.ToString(item[3]).Trim() == AccountSubControlID.Trim() &&

                            creditvalue > 0)
                        {
                            item[6] = (creditvalue + Convert.ToDecimal(Credit));
                            isupdated = true;
                        }
                        else if (Convert.ToString(item[1]).Trim() == AccountHeadID.Trim() &&
                            Convert.ToString(item[2]).Trim() == AccountControlID.Trim() &&
                            Convert.ToString(item[3]).Trim() == AccountSubControlID.Trim() &&

                            debitvalue > 0)
                        {

                            item[7] = (debitvalue + Convert.ToDecimal(Debit));
                            isupdated = true;
                        }
                        //else 
                        //{

                        //    dtEntries.Rows.Add(
                        //    FinancialYearID,
                        //    AccountHeadID,
                        //    AccountControlID,
                        //    AccountSubControlID,
                        //    InvoiceNo,
                        //    UserID,
                        //    Credit,
                        //    Debit,
                        //    TransactionDate,
                        //    TransactionTitle);

                        //}
                    }

                    if (isupdated == true)
                    {
                        dtEntries.Rows.Add(FinancialYearID,
                        AccountHeadID,
                        AccountControlID,
                        AccountSubControlID,
                        InvoiceNo,
                        UserID,
                        Credit,
                        Debit,
                        TransactionDate,
                        TransactionTitle);
                    }

                }
            }
        }

       
    }
}
