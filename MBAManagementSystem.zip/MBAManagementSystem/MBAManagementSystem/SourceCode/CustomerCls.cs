﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.SourceCode
{
   public class CustomerCls
    {

        public static void GetCustomer(string searchvalue, DataGridView dgv)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select CustomerID, CustomerName as [Customer], ContactNo as [Contact No],Area, Address, Description from CustomerTable";
            }
            else
            {
                query = "select CustomerID, CustomerName as [Customer], ContactNo as [Contact No],Area, Address, Description from CustomerTable where (customerName+''+ContactNo+''+Area+''+Address+''+Description) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgv.DataSource = dt;
                    dgv.Columns[0].Width = 100;//CustomerID
                    dgv.Columns[1].Width = 100;//CustomerName
                    dgv.Columns[2].Width = 100;//Contact No
                    dgv.Columns[3].Width = 100;//Area
                    dgv.Columns[4].Width = 200;//Address
                    dgv.Columns[5].Width = 200;//Description
                }
                else
                {
                    dgv.DataSource = null;
                }
            }
            else
            {
                dgv.DataSource = null;
            }

        }

    }
}
