﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBAManagementSystem.SourceCode
{
    public class Accounts
    {

        public static void GetAccountDetails(string AccountTitle, out string AccountHeadID, out string AccountControlID, out string AccountSubControlID)
        {
            string getaccountsubcontrolquery = string.Format("select AccountHeadID, AccountControlID, AccountSubControlID from v_AccountSubControlsList where AccountSubControlName='" + AccountTitle.Trim() + "'");
            DataTable dt = DatabaseAccess.Retrive(getaccountsubcontrolquery);
            if (dt != null)
            {
                if (dt.Rows.Count == 1)
                {

                    AccountHeadID = Convert.ToString(dt.Rows[0][0]);
                    AccountControlID = Convert.ToString(dt.Rows[0][1]);
                    AccountSubControlID = Convert.ToString(dt.Rows[0][2]);
                }
                else
                {
                    dt = null;
                    string getaccountcontrolquery = string.Format("select AccountHeadID, AccountControlID from v_AccountControlsList where AccountControlName='" + AccountTitle.Trim() + "'");
                    dt = DatabaseAccess.Retrive(getaccountcontrolquery);
                    if (dt != null)
                    {
                        if (dt.Rows.Count == 1)
                        {
                            AccountHeadID = Convert.ToString(dt.Rows[0][0]);
                            AccountControlID = Convert.ToString(dt.Rows[0][1]);
                            AccountSubControlID = "0";
                        }
                        else
                        {
                            AccountHeadID = string.Empty;
                            AccountControlID = string.Empty;
                            AccountSubControlID = string.Empty;
                        }
                    }
                    else
                    {
                        AccountHeadID = string.Empty;
                        AccountControlID = string.Empty;
                        AccountSubControlID = string.Empty;
                    }
                }
            }
            else
            {
                dt = null;
                string getaccountcontrolquery = string.Format("select AccountHeadID, AccountControlID from v_AccountControlsList where AccountControlName='" + AccountTitle.Trim() + "'");
                dt = DatabaseAccess.Retrive(getaccountcontrolquery);
                if (dt != null)
                {
                    if (dt.Rows.Count == 1)
                    {
                        AccountHeadID = Convert.ToString(dt.Rows[0][0]);
                        AccountControlID = Convert.ToString(dt.Rows[0][1]);
                        AccountSubControlID = "0";
                    }
                    else
                    {
                        AccountHeadID = string.Empty;
                        AccountControlID = string.Empty;
                        AccountSubControlID = string.Empty;
                    }
                }
                else
                {
                    AccountHeadID = string.Empty;
                    AccountControlID = string.Empty;
                    AccountSubControlID = string.Empty;
                }
            }
        }

        public static void DeletePurchaseInvoiceDetails(string purchaseid) 
        {
            string deletefromdetails = string.Format("delete from SupplierInvoiceDetailsTable where SupplierInvoiceID='"+purchaseid+"'");
            DatabaseAccess.Delete(deletefromdetails);

            string deletefrominvoice = string.Format("delete from SupplierInvoiceTable where SupplierInvoiceID='" + purchaseid + "'");
            DatabaseAccess.Delete(deletefrominvoice);
        }


        public static void DeleteTransactionDetails(string invoiceno)
        {
            string deletedetails = string.Format("delete from SupplierInvoiceDetailsTable where TransactionID='" + invoiceno + "'");
            DatabaseAccess.Delete(deletedetails);
        }

    }
}

