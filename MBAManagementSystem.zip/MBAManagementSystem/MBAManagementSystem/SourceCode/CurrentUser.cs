﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBAManagementSystem
{
   public class CurrentUser
    {
        public static int UserID { get; set; }
        public static int UserTypeID { get; set; }
        public static string UserName { get; set; }
        public static string FullName { get; set; }
        public static string Email { get; set; }
        public static string ContactNo { get; set; }

    }
}
