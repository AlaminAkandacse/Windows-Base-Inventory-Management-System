﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.SourceCode
{
    public class SupplierCls
    {

        public static void GetSupplier(string searchvalue, DataGridView dgv)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select SupplierID [ID], SupplierName [Supplier], ContactNo [Contact No], Address,Email, Description from SupplierTable";
            }
            else
            {
                query = "select SupplierID [ID], SupplierName [Supplier], ContactNo [Contact No], Address, Email,Description from SupplierTable where (SupplierName+''+ContactNo+''+Email+''+Address+''+Description) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrive(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgv.DataSource = dt;
                    dgv.Columns[0].Width = 100;
                    dgv.Columns[1].Width = 100;
                    dgv.Columns[2].Width = 100;
                    dgv.Columns[3].Width = 100;
                    dgv.Columns[4].Width = 200;
                    dgv.Columns[5].Width = 200;
                }
                else
                {
                    dgv.DataSource = null;
                }
            }
            else
            {
                dgv.DataSource = null;
            }

        }


    }
}
