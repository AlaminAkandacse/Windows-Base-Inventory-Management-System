﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.SourceCode
{
  public  class GridViewDesign
    {
        public static void JournalGridviewDesign(DataGridView dgvDesign) 
        {
            dgvDesign.RowHeadersVisible = false;
            dgvDesign.AllowUserToAddRows = false;
            dgvDesign.ReadOnly = true;
            dgvDesign.MultiSelect = false;
            dgvDesign.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDesign.AllowUserToResizeRows = false;
            dgvDesign.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.None;
            dgvDesign.AdvancedCellBorderStyle.Bottom = DataGridViewAdvancedCellBorderStyle.None;
            dgvDesign.AdvancedCellBorderStyle.Right = DataGridViewAdvancedCellBorderStyle.Single;
            dgvDesign.AdvancedCellBorderStyle.Left = DataGridViewAdvancedCellBorderStyle.None;
            dgvDesign.AdvancedColumnHeadersBorderStyle.All = DataGridViewAdvancedCellBorderStyle.None;
            dgvDesign.GridColor = Color.Gainsboro;
            dgvDesign.EnableHeadersVisualStyles = false;
            dgvDesign.RowsDefaultCellStyle.SelectionBackColor = SystemColors.GradientInactiveCaption;
            dgvDesign.RowsDefaultCellStyle.SelectionForeColor = Color.Black;
            dgvDesign.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvDesign.ColumnHeadersDefaultCellStyle.Padding = new Padding(5,5,5,5);
            dgvDesign.ColumnHeadersHeight = 300;
            foreach (DataGridViewColumn column in dgvDesign.Columns) 
            {

                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn col in dgvDesign.Columns) 
            {
                if (col.HeaderText=="Debit" || col.HeaderText == "Credit") 
                {
                    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                    col.HeaderCell.Style.Font = new Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Pixel);
                }
                col.HeaderCell.Style.Font = new Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

        }
    }
}
