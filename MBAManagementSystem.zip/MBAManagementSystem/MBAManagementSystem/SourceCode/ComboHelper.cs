﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBAManagementSystem.SourceCode
{
    public class ComboHelper
    {
        public static void FillUserTypes(ComboBox cmb) 
        {
            DataTable dtUserType = new DataTable();
            dtUserType.Columns.Add("UserTypeID");
            dtUserType.Columns.Add("UserType");
            dtUserType.Rows.Add("0","---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select UserTypeID, UserType from UserTypesTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtUserType.Rows.Add(usertype["UserTypeID"], usertype["UserType"]);
                        }

                    }

                }

                cmb.DataSource = dtUserType;
                cmb.ValueMember = "UserTypeID";
                cmb.DisplayMember = "UserType";
            }
            catch 
            {
                cmb.DataSource = dtUserType;
            }


        }


        public static void FillFinancialYear(ComboBox cmb)
        {
            DataTable dtFinancialYear = new DataTable();
            dtFinancialYear.Columns.Add("FinancialYearID");
            dtFinancialYear.Columns.Add("FinancialYear");
            dtFinancialYear.Rows.Add("0", "---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select FinancialYearID, FinancialYear from FinancialYearTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtFinancialYear.Rows.Add(usertype["FinancialYearID"], usertype["FinancialYear"]);
                        }

                    }

                }

                cmb.DataSource = dtFinancialYear;
                cmb.ValueMember = "FinancialYearID";
                cmb.DisplayMember = "FinancialYear";
            }
            catch
            {
                cmb.DataSource = dtFinancialYear;
            }


        }



        public static void FillCategories(ComboBox cmb)
        {
            DataTable dtCategory = new DataTable();
            dtCategory.Columns.Add("CategoryID");
            dtCategory.Columns.Add("CategoryName");
            dtCategory.Rows.Add("0", "---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select CategoryID, CategoryName from CategoryTable where IsDeleted=0");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtCategory.Rows.Add(usertype["CategoryID"], usertype["CategoryName"]);
                        }

                    }

                }

                cmb.DataSource = dtCategory;
                cmb.ValueMember = "CategoryID";
                cmb.DisplayMember = "CategoryName";
            }
            catch
            {
                cmb.DataSource = dtCategory;
            }


        }

        public static void FillProductByCategory(ComboBox cmb, string categoryid)
        {
            DataTable dtProduct = new DataTable();
            dtProduct.Columns.Add("ProductID");
            dtProduct.Columns.Add("ProductName");
            dtProduct.Rows.Add("0", "---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select ProductID, ProductName from StockTable where CategoryID='"+categoryid.Trim()+"' and IsDeleted=0");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtProduct.Rows.Add(usertype["ProductID"], usertype["ProductName"]);
                        }

                    }

                }

                cmb.DataSource = dtProduct;
                cmb.ValueMember = "ProductID";
                cmb.DisplayMember = "ProductName";
            }
            catch
            {
                cmb.DataSource = dtProduct;
            }


        }


        public static void FillAccountHead(ComboBox cmb)
        {
            DataTable dtAccounts= new DataTable();
            dtAccounts.Columns.Add("AccountHeadID");
            dtAccounts.Columns.Add("AccountHeadName");
            dtAccounts.Rows.Add("0", "---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select AccountHeadID, AccountHeadName from AccountHeadTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtAccounts.Rows.Add(usertype["AccountHeadID"], usertype["AccountHeadName"]);
                        }

                    }

                }

                cmb.DataSource = dtAccounts;
                cmb.ValueMember = "AccountHeadID";
                cmb.DisplayMember = "AccountHeadName";
            }
            catch
            {
                cmb.DataSource = dtAccounts;
            }


        }

        public static void FillAccountHeadControls(ComboBox cmb, object headid)
        {
            DataTable dtAccountControls = new DataTable();
            dtAccountControls.Columns.Add("AccountControlID");
            dtAccountControls.Columns.Add("AccountControlName");
            dtAccountControls.Rows.Add("0", "---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select AccountControlID, AccountControlName from AccountControlTable where AccountHeadID='"+headid+"'");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow accountcontrol in dt.Rows)
                        {
                            dtAccountControls.Rows.Add(accountcontrol["AccountControlID"], accountcontrol["AccountControlName"]);
                        }

                    }

                }

                cmb.DataSource = dtAccountControls;
                cmb.ValueMember = "AccountControlID";
                cmb.DisplayMember = "AccountControlName";
            }
            catch
            {
                cmb.DataSource = dtAccountControls;
            }


        }


        public static void FillAccountHeadControls(ComboBox cmb)
        {
            DataTable dtAccountControls = new DataTable();
            dtAccountControls.Columns.Add("AccountControlID");
            dtAccountControls.Columns.Add("AccountControlName");
            dtAccountControls.Rows.Add("0", "---Select---");

            try
            {

                DataTable dt = DatabaseAccess.Retrive("select AccountControlID, AccountControlName from AccountControlTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow accountcontrol in dt.Rows)
                        {
                            dtAccountControls.Rows.Add(accountcontrol["AccountControlID"], accountcontrol["AccountControlName"]);
                        }

                    }

                }

                cmb.DataSource = dtAccountControls;
                cmb.ValueMember = "AccountControlID";
                cmb.DisplayMember = "AccountControlName";
            }
            catch
            {
                cmb.DataSource = dtAccountControls;
            }


        }

    }
}
